import { useEffect, useState } from "react";

/**
 * Animates from 0 to `target` over `durationMs`, using an eased curve.
 * Used for the hero stats, confidence meters, and authenticity scores.
 */
export function useCountUp(target: number, durationMs = 1400, shouldStart = true): number {
  const [value, setValue] = useState(0);

  useEffect(() => {
    if (!shouldStart) return;

    let frame: number;
    const start = performance.now();

    const tick = (now: number) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / durationMs, 1);
      const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
      setValue(Math.round(eased * target * 100) / 100);

      if (progress < 1) {
        frame = requestAnimationFrame(tick);
      }
    };

    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [target, durationMs, shouldStart]);

  return value;
}

import { describe, it, expect } from "vitest";
import { formatFileSize, formatPercent } from "@/utils/format";

describe("formatFileSize", () => {
  it("formats bytes", () => {
    expect(formatFileSize(500)).toBe("500 B");
  });

  it("formats kilobytes", () => {
    expect(formatFileSize(2048)).toBe("2.0 KB");
  });

  it("formats megabytes", () => {
    expect(formatFileSize(5 * 1024 * 1024)).toBe("5.0 MB");
  });
});

describe("formatPercent", () => {
  it("formats with default 1 decimal", () => {
    expect(formatPercent(97.856)).toBe("97.9%");
  });

  it("formats with custom decimals", () => {
    expect(formatPercent(97.856, 0)).toBe("98%");
  });
});

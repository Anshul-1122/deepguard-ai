import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { VerdictBadge } from "@/components/ui/VerdictBadge";

describe("VerdictBadge", () => {
  it("renders REAL verdict text", () => {
    render(<VerdictBadge verdict="REAL" />);
    expect(screen.getByText("REAL")).toBeInTheDocument();
  });

  it("renders FAKE verdict text", () => {
    render(<VerdictBadge verdict="FAKE" />);
    expect(screen.getByText("FAKE")).toBeInTheDocument();
  });
});

export interface User {
  id: string;
  email: string;
  full_name: string | null;
  created_at: string;
}

export interface AuthResponse {
  access_token: string;
  token_type: string;
  user: User;
}

export type Verdict = "REAL" | "FAKE";

export interface PredictionResult {
  scan_id: string;
  prediction: Verdict;
  confidence_score: number;
  authenticity_score: number;
  real_probability: number;
  fake_probability: number;
  faces_detected: number;
  explanation: string;
  heatmap_url: string | null;
  original_url: string;
  inference_time_ms: number;
  model_version: string;
  is_mock_model: boolean;
  created_at: string;
}

export interface ScanHistoryItem {
  id: string;
  media_type: string;
  original_filename: string;
  original_url: string;
  heatmap_url: string | null;
  thumbnail_url: string | null;
  prediction: Verdict;
  confidence_score: number;
  authenticity_score: number;
  faces_detected: number;
  created_at: string;
}

export interface ScanHistoryResponse {
  total: number;
  items: ScanHistoryItem[];
}

export interface ApiErrorShape {
  detail: string;
}

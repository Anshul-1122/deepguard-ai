import { apiClient } from "./api";
import type { AuthResponse, User } from "@/types";

export async function signup(email: string, password: string, fullName?: string): Promise<AuthResponse> {
  const { data } = await apiClient.post<AuthResponse>("/auth/signup", {
    email,
    password,
    full_name: fullName || null,
  });
  return data;
}

export async function login(email: string, password: string): Promise<AuthResponse> {
  const { data } = await apiClient.post<AuthResponse>("/auth/login", { email, password });
  return data;
}

export async function fetchCurrentUser(): Promise<User> {
  const { data } = await apiClient.get<User>("/auth/me");
  return data;
}

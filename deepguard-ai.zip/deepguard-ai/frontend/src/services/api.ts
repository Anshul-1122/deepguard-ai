import axios, { AxiosError } from "axios";

// Vite's dev server proxies /api -> http://localhost:8000 (see vite.config.ts),
// and in production this should be same-origin or set via VITE_API_BASE_URL.
const baseURL = import.meta.env.VITE_API_BASE_URL || "/api";

export const apiClient = axios.create({
  baseURL,
  timeout: 30_000,
});

apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem("deepguard_token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export interface NormalizedApiError {
  message: string;
  status: number | null;
}

export function normalizeApiError(error: unknown): NormalizedApiError {
  if (axios.isAxiosError(error)) {
    const axiosError = error as AxiosError<{ detail?: string }>;
    const detail = axiosError.response?.data?.detail;
    return {
      message: detail || axiosError.message || "Something went wrong. Please try again.",
      status: axiosError.response?.status ?? null,
    };
  }
  return { message: "An unexpected error occurred.", status: null };
}

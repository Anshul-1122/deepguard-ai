import { apiClient } from "./api";
import type { PredictionResult, ScanHistoryResponse } from "@/types";

export async function predictImage(
  file: File,
  onUploadProgress?: (percent: number) => void
): Promise<PredictionResult> {
  const formData = new FormData();
  formData.append("file", file);

  const { data } = await apiClient.post<PredictionResult>("/predict", formData, {
    headers: { "Content-Type": "multipart/form-data" },
    onUploadProgress: (event) => {
      if (onUploadProgress && event.total) {
        onUploadProgress(Math.round((event.loaded / event.total) * 100));
      }
    },
  });
  return data;
}

export interface HistoryFilters {
  search?: string;
  prediction?: "REAL" | "FAKE" | "";
  limit?: number;
  offset?: number;
}

export async function fetchHistory(filters: HistoryFilters = {}): Promise<ScanHistoryResponse> {
  const { data } = await apiClient.get<ScanHistoryResponse>("/history", {
    params: {
      search: filters.search || undefined,
      prediction: filters.prediction || undefined,
      limit: filters.limit ?? 50,
      offset: filters.offset ?? 0,
    },
  });
  return data;
}

export async function deleteScan(scanId: string): Promise<void> {
  await apiClient.delete(`/history/${scanId}`);
}

export function reportDownloadUrl(scanId: string): string {
  const baseURL = apiClient.defaults.baseURL || "/api";
  return `${baseURL}/report/${scanId}`;
}

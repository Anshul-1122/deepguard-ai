import { Activity, Cpu } from "lucide-react";

interface StatusCardProps {
  modelVersion?: string;
  isMock?: boolean;
}

export function StatusCard({ modelVersion, isMock }: StatusCardProps) {
  return (
    <div className="card">
      <div className="flex items-center gap-2 mb-4">
        <Activity size={16} className="text-verdict-real" />
        <h3 className="font-display font-semibold text-sm">System status</h3>
      </div>
      <div className="flex flex-col gap-3 text-sm">
        <div className="flex items-center justify-between">
          <span className="text-white/50">API</span>
          <span className="flex items-center gap-1.5 text-verdict-real">
            <span className="w-1.5 h-1.5 rounded-full bg-verdict-real animate-pulse" />
            Online
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-white/50">Model</span>
          <span className="flex items-center gap-1.5 text-white/70">
            <Cpu size={13} />
            {isMock ? "Demo mode" : "Trained"}
          </span>
        </div>
        {modelVersion && (
          <div className="flex items-center justify-between">
            <span className="text-white/50">Version</span>
            <span className="font-mono text-xs text-white/60 truncate max-w-[140px]">{modelVersion}</span>
          </div>
        )}
      </div>
      {isMock && (
        <p className="text-xs text-white/40 mt-4 pt-4 border-t border-white/[0.06] leading-relaxed">
          Running on demo predictions — no trained weights found. Predictions are deterministic but not from a real model.
        </p>
      )}
    </div>
  );
}

import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ImageOff } from "lucide-react";
import type { ScanHistoryItem } from "@/types";
import { VerdictBadge } from "@/components/ui/VerdictBadge";
import { Skeleton } from "@/components/ui/Skeleton";
import { formatDate } from "@/utils/format";

interface RecentUploadsListProps {
  items: ScanHistoryItem[];
  isLoading: boolean;
}

export function RecentUploadsList({ items, isLoading }: RecentUploadsListProps) {
  if (isLoading) {
    return (
      <div className="flex flex-col gap-3">
        {[...Array(4)].map((_, i) => (
          <Skeleton key={i} className="h-16 w-full" />
        ))}
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="text-center py-10">
        <ImageOff size={28} className="text-white/20 mx-auto mb-3" />
        <p className="text-sm text-white/40">No scans yet. Upload your first image to get started.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-2">
      {items.map((item, i) => (
        <motion.div
          key={item.id}
          initial={{ opacity: 0, x: -8 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: i * 0.05 }}
        >
          <Link
            to="/history"
            className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-white/[0.04] transition-colors group"
          >
            {item.thumbnail_url ? (
              <img
                src={item.thumbnail_url}
                alt={item.original_filename}
                className="w-11 h-11 rounded-lg object-cover shrink-0"
              />
            ) : (
              <div className="w-11 h-11 rounded-lg bg-white/5 shrink-0" />
            )}
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate group-hover:text-white transition-colors">
                {item.original_filename}
              </p>
              <p className="text-xs text-white/40">{formatDate(item.created_at)}</p>
            </div>
            <VerdictBadge verdict={item.prediction} size="sm" />
          </Link>
        </motion.div>
      ))}
    </div>
  );
}

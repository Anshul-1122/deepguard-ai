import { useCallback, useState } from "react";
import { useDropzone, type FileRejection } from "react-dropzone";
import { motion, AnimatePresence } from "framer-motion";
import { UploadCloud, ImageIcon, Film, X } from "lucide-react";
import { formatFileSize } from "@/utils/format";

interface UploadDropzoneProps {
  onFileAccepted: (file: File) => void;
  disabled?: boolean;
}

const ACCEPTED_TYPES = {
  "image/jpeg": [".jpg", ".jpeg"],
  "image/png": [".png"],
  "image/webp": [".webp"],
};

export function UploadDropzone({ onFileAccepted, disabled }: UploadDropzoneProps) {
  const [preview, setPreview] = useState<{ file: File; url: string } | null>(null);
  const [rejectionError, setRejectionError] = useState<string | null>(null);

  const onDrop = useCallback(
    (accepted: File[], rejections: FileRejection[]) => {
      setRejectionError(null);
      if (rejections.length > 0) {
        setRejectionError(
          rejections[0].errors[0]?.message || "This file couldn't be uploaded. Try a JPG, PNG, or WebP under 15MB."
        );
        return;
      }
      const file = accepted[0];
      if (!file) return;
      const url = URL.createObjectURL(file);
      setPreview({ file, url });
      onFileAccepted(file);
    },
    [onFileAccepted]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: ACCEPTED_TYPES,
    maxSize: 15 * 1024 * 1024,
    multiple: false,
    disabled,
  });

  const clearPreview = () => {
    if (preview) URL.revokeObjectURL(preview.url);
    setPreview(null);
  };

  return (
    <div>
      <div
        {...getRootProps()}
        className={`relative rounded-2xl border-2 border-dashed transition-all duration-300 cursor-pointer
          ${isDragActive ? "border-secondary bg-secondary/5 scale-[1.01]" : "border-white/15 hover:border-primary/40"}
          ${disabled ? "opacity-60 cursor-not-allowed" : ""}
          ${preview ? "p-4" : "p-14"}
        `}
      >
        <input {...getInputProps()} />

        <AnimatePresence mode="wait">
          {preview ? (
            <motion.div
              key="preview"
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              className="relative flex items-center gap-4"
            >
              <img src={preview.url} alt="Selected upload preview" className="w-20 h-20 rounded-xl object-cover" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{preview.file.name}</p>
                <p className="text-xs text-white/50">{formatFileSize(preview.file.size)}</p>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  clearPreview();
                }}
                className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
                aria-label="Remove selected file"
              >
                <X size={14} />
              </button>
            </motion.div>
          ) : (
            <motion.div
              key="empty"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center text-center gap-4"
            >
              <motion.div
                animate={isDragActive ? { scale: 1.1, rotate: 5 } : { scale: 1, rotate: 0 }}
                className="w-16 h-16 rounded-2xl bg-gradient-brand/20 flex items-center justify-center"
              >
                <UploadCloud size={28} className="text-secondary" />
              </motion.div>
              <div>
                <p className="font-display font-medium text-lg mb-1">
                  {isDragActive ? "Drop it here" : "Drag & drop an image"}
                </p>
                <p className="text-sm text-white/50">or click to browse — JPG, PNG, WebP up to 15MB</p>
              </div>
              <div className="flex items-center gap-4 text-xs text-white/40 mt-1">
                <span className="flex items-center gap-1.5">
                  <ImageIcon size={13} /> Images
                </span>
                <span className="flex items-center gap-1.5 opacity-40">
                  <Film size={13} /> Video (coming soon)
                </span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {rejectionError && <p className="text-sm text-verdict-fake mt-3">{rejectionError}</p>}
    </div>
  );
}

import { useState } from "react";
import { motion } from "framer-motion";

interface ImageComparisonProps {
  originalUrl: string;
  heatmapUrl: string | null;
}

export function ImageComparison({ originalUrl, heatmapUrl }: ImageComparisonProps) {
  const [showHeatmap, setShowHeatmap] = useState(true);

  return (
    <div>
      <div className="relative rounded-2xl overflow-hidden aspect-square glass-strong">
        <img src={originalUrl} alt="Original upload" className="absolute inset-0 w-full h-full object-cover" />
        {heatmapUrl && (
          <motion.img
            src={heatmapUrl}
            alt="Grad-CAM heatmap overlay showing suspicious regions"
            className="absolute inset-0 w-full h-full object-cover"
            animate={{ opacity: showHeatmap ? 1 : 0 }}
            transition={{ duration: 0.3 }}
          />
        )}
      </div>

      {heatmapUrl && (
        <div className="flex items-center justify-center gap-1 mt-4 glass rounded-full p-1 w-fit mx-auto">
          <button
            onClick={() => setShowHeatmap(false)}
            className={`px-4 py-1.5 rounded-full text-xs font-medium transition-colors ${
              !showHeatmap ? "bg-white/10 text-white" : "text-white/50"
            }`}
          >
            Original
          </button>
          <button
            onClick={() => setShowHeatmap(true)}
            className={`px-4 py-1.5 rounded-full text-xs font-medium transition-colors ${
              showHeatmap ? "bg-white/10 text-white" : "text-white/50"
            }`}
          >
            Heatmap
          </button>
        </div>
      )}
    </div>
  );
}

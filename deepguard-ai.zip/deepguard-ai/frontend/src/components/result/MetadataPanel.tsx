import { Clock, Users, Cpu, Calendar } from "lucide-react";
import { formatDate } from "@/utils/format";
import type { PredictionResult } from "@/types";

export function MetadataPanel({ result }: { result: PredictionResult }) {
  const rows = [
    { icon: Clock, label: "Inference time", value: `${result.inference_time_ms.toFixed(0)} ms` },
    { icon: Users, label: "Faces detected", value: String(result.faces_detected) },
    { icon: Cpu, label: "Model", value: result.model_version },
    { icon: Calendar, label: "Scanned", value: formatDate(result.created_at) },
  ];

  return (
    <div className="card">
      <h3 className="font-display font-semibold text-sm mb-4">Metadata</h3>
      <div className="flex flex-col gap-3.5">
        {rows.map((row) => (
          <div key={row.label} className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-2 text-white/50">
              <row.icon size={14} />
              {row.label}
            </span>
            <span className="font-mono text-xs text-white/80 truncate max-w-[160px] text-right">{row.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

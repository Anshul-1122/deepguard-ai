import { useEffect, useRef } from "react";
import {
  Chart,
  BarController,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
} from "chart.js";

Chart.register(BarController, BarElement, CategoryScale, LinearScale, Tooltip);

interface ProbabilityChartProps {
  realProbability: number; // 0-1
  fakeProbability: number; // 0-1
}

export function ProbabilityChart({ realProbability, fakeProbability }: ProbabilityChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<Chart | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    chartRef.current?.destroy();

    chartRef.current = new Chart(canvasRef.current, {
      type: "bar",
      data: {
        labels: ["Real", "Fake"],
        datasets: [
          {
            data: [realProbability * 100, fakeProbability * 100],
            backgroundColor: ["#22C55E", "#EF4444"],
            borderRadius: 8,
            barThickness: 48,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: { duration: 1000, easing: "easeOutQuart" },
        plugins: {
          tooltip: {
            callbacks: {
              label: (ctx) => `${ctx.raw as number}%`.replace(/(\.\d)\d+/, "$1"),
            },
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            max: 100,
            grid: { color: "rgba(255,255,255,0.06)" },
            ticks: { color: "rgba(255,255,255,0.4)", callback: (v) => `${v}%` },
          },
          x: {
            grid: { display: false },
            ticks: { color: "rgba(255,255,255,0.7)", font: { family: "Inter" } },
          },
        },
      },
    });

    return () => chartRef.current?.destroy();
  }, [realProbability, fakeProbability]);

  return (
    <div className="h-56">
      <canvas ref={canvasRef} />
    </div>
  );
}

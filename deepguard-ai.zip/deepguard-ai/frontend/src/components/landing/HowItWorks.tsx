import { motion } from "framer-motion";
import { Upload, ScanFace, Cpu, FileCheck2 } from "lucide-react";
import { useInView } from "@/hooks/useInView";

const STEPS = [
  {
    icon: Upload,
    title: "Upload your media",
    description: "Drop in an image or video. We support JPG, PNG, WebP, and MP4.",
  },
  {
    icon: ScanFace,
    title: "Face detection & preprocessing",
    description: "We locate the primary face, crop it, and normalize it for the model.",
  },
  {
    icon: Cpu,
    title: "EfficientNetB0 inference",
    description: "A fine-tuned deep network scores the face as REAL or FAKE with a confidence value.",
  },
  {
    icon: FileCheck2,
    title: "Explanation & report",
    description: "Grad-CAM highlights suspicious regions, and you get a downloadable PDF report.",
  },
];

export function HowItWorks() {
  const { ref, isInView } = useInView<HTMLDivElement>();

  return (
    <section id="how-it-works" ref={ref} className="px-6 py-28 border-t border-white/[0.06]">
      <div className="max-w-6xl mx-auto">
        <div className="max-w-lg mb-16">
          <p className="label-eyebrow mb-3">The pipeline</p>
          <h2 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight">How it works</h2>
        </div>

        <div className="relative grid md:grid-cols-4 gap-8">
          <div className="hidden md:block absolute top-7 left-[12.5%] right-[12.5%] h-px bg-gradient-to-r from-primary/40 via-secondary/40 to-primary/40" />

          {STEPS.map((step, i) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 24 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: i * 0.12 }}
              className="relative"
            >
              <div className="relative z-10 w-14 h-14 rounded-2xl bg-background border border-white/10 flex items-center justify-center mb-5">
                <step.icon size={22} className="text-secondary" />
                <span className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-gradient-brand text-[10px] font-mono flex items-center justify-center font-semibold">
                  {i + 1}
                </span>
              </div>
              <h3 className="font-display font-semibold mb-2">{step.title}</h3>
              <p className="text-sm text-white/55 leading-relaxed">{step.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

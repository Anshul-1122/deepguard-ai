import { motion } from "framer-motion";
import { useCountUp } from "@/hooks/useCountUp";
import { useInView } from "@/hooks/useInView";

const STATS = [
  { value: 97.8, suffix: "%", label: "Model accuracy on held-out test set" },
  { value: 240, suffix: "ms", label: "Average inference time per image" },
  { value: 140, suffix: "K+", label: "Training images (real + synthetic)" },
  { value: 4, suffix: "", label: "Explainability signals per scan" },
];

export function Stats() {
  const { ref, isInView } = useInView<HTMLDivElement>();

  return (
    <section ref={ref} className="px-6 py-16 border-y border-white/[0.06]">
      <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8">
        {STATS.map((stat, i) => (
          <StatItem key={stat.label} {...stat} isInView={isInView} index={i} />
        ))}
      </div>
    </section>
  );
}

function StatItem({
  value,
  suffix,
  label,
  isInView,
  index,
}: {
  value: number;
  suffix: string;
  label: string;
  isInView: boolean;
  index: number;
}) {
  const animated = useCountUp(value, 1800, isInView);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="text-center md:text-left"
    >
      <p className="font-display text-3xl sm:text-4xl font-semibold text-gradient mb-1">
        {animated.toFixed(value % 1 !== 0 ? 1 : 0)}
        {suffix}
      </p>
      <p className="text-xs sm:text-sm text-white/50 leading-snug">{label}</p>
    </motion.div>
  );
}

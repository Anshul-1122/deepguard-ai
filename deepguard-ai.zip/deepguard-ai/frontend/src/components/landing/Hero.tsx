import { useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import gsap from "gsap";
import { ArrowRight, ShieldCheck, Sparkles } from "lucide-react";
import { FloatingParticles } from "@/components/animations/FloatingParticles";
import { useCountUp } from "@/hooks/useCountUp";

function LiveConfidenceReadout() {
  const confidence = useCountUp(97.8, 2200);
  return (
    <div className="relative w-full max-w-xs mx-auto">
      <div className="glass-strong rounded-2xl p-5 glow-border">
        <div className="relative rounded-xl overflow-hidden aspect-square bg-gradient-to-br from-primary/20 to-secondary/10 mb-4">
          {/* Abstract face silhouette, not a real photo — avoids depicting a real person */}
          <svg viewBox="0 0 200 200" className="w-full h-full opacity-60">
            <ellipse cx="100" cy="90" rx="55" ry="68" fill="none" stroke="#A78BFA" strokeWidth="1.5" />
            <circle cx="78" cy="80" r="4" fill="#00E5FF" />
            <circle cx="122" cy="80" r="4" fill="#00E5FF" />
            <path d="M80 115 Q100 128 120 115" stroke="#A78BFA" strokeWidth="1.5" fill="none" />
          </svg>
          <motion.div
            className="absolute inset-x-0 h-0.5 bg-gradient-to-r from-transparent via-secondary to-transparent"
            animate={{ top: ["10%", "90%", "10%"] }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          />
          <div className="absolute top-2 left-2 flex items-center gap-1.5 bg-black/40 backdrop-blur-sm rounded-full px-2.5 py-1">
            <span className="w-1.5 h-1.5 rounded-full bg-secondary animate-pulse" />
            <span className="text-[10px] font-mono text-white/80">ANALYZING</span>
          </div>
        </div>
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-xs font-mono text-white/50 uppercase tracking-wide">Authenticity</span>
          <span className="text-xs font-mono text-verdict-fake">FAKE</span>
        </div>
        <div className="h-2 rounded-full bg-white/[0.06] overflow-hidden mb-3">
          <motion.div
            className="h-full bg-gradient-to-r from-verdict-fake to-orange-400"
            initial={{ width: "0%" }}
            animate={{ width: `${100 - confidence}%` }}
            transition={{ duration: 2.2, ease: "easeOut" }}
          />
        </div>
        <div className="flex items-baseline justify-between">
          <span className="text-3xl font-mono font-semibold">{confidence.toFixed(1)}%</span>
          <span className="text-xs text-white/40">confidence</span>
        </div>
      </div>
    </div>
  );
}

export function Hero() {
  const headlineRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    if (!headlineRef.current) return;
    const words = headlineRef.current.querySelectorAll(".hero-word");
    gsap.fromTo(
      words,
      { y: 60, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.9, ease: "power4.out", stagger: 0.08 }
    );
  }, []);

  return (
    <section className="relative pt-40 pb-24 px-6 overflow-hidden">
      <FloatingParticles />
      <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-primary/20 rounded-full blur-[120px] pointer-events-none" />

      <div className="relative max-w-6xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
        <div>
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 glass rounded-full px-4 py-1.5 mb-6"
          >
            <Sparkles size={13} className="text-secondary" />
            <span className="text-xs font-mono text-white/70">EfficientNet-powered · Explainable AI</span>
          </motion.div>

          <h1
            ref={headlineRef}
            className="font-display text-5xl sm:text-6xl lg:text-[3.4rem] font-semibold leading-[1.08] tracking-tight mb-6"
          >
            <span className="hero-word inline-block">See</span>{" "}
            <span className="hero-word inline-block">through</span>{" "}
            <span className="hero-word inline-block text-gradient">every</span>{" "}
            <span className="hero-word inline-block text-gradient">pixel.</span>
            <br />
            <span className="hero-word inline-block">Know</span>{" "}
            <span className="hero-word inline-block">what's</span>{" "}
            <span className="hero-word inline-block">real.</span>
          </h1>

          <p className="text-white/60 text-lg max-w-md mb-9 leading-relaxed">
            DeepGuard AI analyzes faces frame by frame, pixel by pixel — flagging AI-generated
            and manipulated media with a confidence score and a visual explanation you can trust.
          </p>

          <div className="flex flex-wrap items-center gap-4">
            <Link to="/dashboard" className="btn-primary">
              Analyze a photo
              <ArrowRight size={16} />
            </Link>
            <a href="#how-it-works" className="btn-secondary">
              <ShieldCheck size={16} />
              How it works
            </a>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3, ease: "easeOut" }}
        >
          <LiveConfidenceReadout />
        </motion.div>
      </div>
    </section>
  );
}

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown } from "lucide-react";
import { useInView } from "@/hooks/useInView";

const FAQS = [
  {
    question: "How accurate is DeepGuard AI?",
    answer:
      "Our EfficientNetB0 model achieves roughly 97.8% accuracy on held-out test data from the training distribution. Accuracy on out-of-distribution media (new generation techniques, heavy compression) may vary — we recommend treating results as a strong signal, not an absolute verdict.",
  },
  {
    question: "What file types can I upload?",
    answer: "Images: JPG, PNG, and WebP. Video: MP4, MOV, and WebM, up to 15MB per file.",
  },
  {
    question: "Is my uploaded media stored?",
    answer:
      "Yes, uploads are stored so you can revisit them in your scan history and download reports later. You can delete any scan permanently from the History page at any time.",
  },
  {
    question: "What does the Grad-CAM heatmap show?",
    answer:
      "It highlights the regions of the face that most influenced the model's prediction — typically around the eyes, mouth, and skin texture boundaries where synthetic artifacts tend to appear.",
  },
  {
    question: "Do I need an account to use it?",
    answer:
      "No — you can analyze media as a guest. Creating an account lets you keep a persistent, searchable history tied to your profile across devices.",
  },
];

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const { ref, isInView } = useInView<HTMLDivElement>();

  return (
    <section id="faq" ref={ref} className="px-6 py-28 border-t border-white/[0.06]">
      <div className="max-w-3xl mx-auto">
        <div className="mb-12">
          <p className="label-eyebrow mb-3">Questions</p>
          <h2 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight">
            Frequently asked questions
          </h2>
        </div>

        <div className="flex flex-col gap-3">
          {FAQS.map((faq, i) => {
            const isOpen = openIndex === i;
            return (
              <motion.div
                key={faq.question}
                initial={{ opacity: 0, y: 12 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.4, delay: i * 0.06 }}
                className="glass rounded-xl overflow-hidden"
              >
                <button
                  onClick={() => setOpenIndex(isOpen ? null : i)}
                  className="w-full flex items-center justify-between gap-4 px-5 py-4 text-left"
                  aria-expanded={isOpen}
                >
                  <span className="font-medium text-white/90">{faq.question}</span>
                  <ChevronDown
                    size={18}
                    className={`text-white/40 shrink-0 transition-transform duration-300 ${isOpen ? "rotate-180" : ""}`}
                  />
                </button>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.25 }}
                    >
                      <p className="px-5 pb-5 text-sm text-white/55 leading-relaxed">{faq.answer}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

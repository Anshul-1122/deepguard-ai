import { motion } from "framer-motion";
import { Eye, Gauge, FileDown, History, ShieldCheck, Zap } from "lucide-react";
import { useInView } from "@/hooks/useInView";

const FEATURES = [
  {
    icon: Eye,
    title: "Grad-CAM heatmaps",
    description: "See exactly which regions of a face drove the model's decision — not just a score.",
  },
  {
    icon: Gauge,
    title: "Confidence & authenticity scores",
    description: "Two complementary metrics: how sure the model is, and how genuine the media looks.",
  },
  {
    icon: Zap,
    title: "Sub-second inference",
    description: "EfficientNetB0 runs fast enough for real-time triage of images and video frames.",
  },
  {
    icon: History,
    title: "Full scan history",
    description: "Every analysis is saved, searchable, and filterable — build an audit trail over time.",
  },
  {
    icon: FileDown,
    title: "Downloadable PDF reports",
    description: "Export a shareable report with the image, heatmap, scores, and a written explanation.",
  },
  {
    icon: ShieldCheck,
    title: "Multi-face detection",
    description: "Automatically detects and isolates the primary face — even in group or noisy photos.",
  },
];

export function Features() {
  const { ref, isInView } = useInView<HTMLDivElement>();

  return (
    <section ref={ref} className="px-6 py-28">
      <div className="max-w-6xl mx-auto">
        <div className="max-w-lg mb-14">
          <p className="label-eyebrow mb-3">Capabilities</p>
          <h2 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight">
            Detection you can actually explain.
          </h2>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {FEATURES.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: i * 0.07 }}
              whileHover={{ y: -4 }}
              className="card group hover:border-primary/30 transition-colors"
            >
              <div className="w-11 h-11 rounded-xl bg-gradient-brand/20 flex items-center justify-center mb-4 group-hover:bg-gradient-brand transition-colors duration-300">
                <feature.icon size={20} className="text-secondary group-hover:text-white transition-colors" />
              </div>
              <h3 className="font-display font-semibold text-lg mb-2">{feature.title}</h3>
              <p className="text-sm text-white/55 leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

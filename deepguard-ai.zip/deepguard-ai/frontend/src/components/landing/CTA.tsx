import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { useInView } from "@/hooks/useInView";

export function CTA() {
  const { ref, isInView } = useInView<HTMLDivElement>();

  return (
    <section ref={ref} className="px-6 py-24">
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={isInView ? { opacity: 1, scale: 1 } : {}}
        transition={{ duration: 0.6 }}
        className="relative max-w-4xl mx-auto rounded-3xl glass-strong p-12 sm:p-16 text-center overflow-hidden"
      >
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-primary/30 rounded-full blur-[100px]" />
        <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-secondary/20 rounded-full blur-[100px]" />

        <div className="relative">
          <h2 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight mb-4">
            Not sure if it's real?
          </h2>
          <p className="text-white/60 max-w-md mx-auto mb-8">
            Upload a photo and get a confidence-scored, explainable answer in under a second.
          </p>
          <Link to="/dashboard" className="btn-primary">
            Try DeepGuard AI free
            <ArrowRight size={16} />
          </Link>
        </div>
      </motion.div>
    </section>
  );
}

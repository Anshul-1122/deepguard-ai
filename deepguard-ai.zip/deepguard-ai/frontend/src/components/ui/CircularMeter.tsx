import { motion } from "framer-motion";
import { useCountUp } from "@/hooks/useCountUp";

interface CircularMeterProps {
  value: number; // 0-100
  label: string;
  colorFrom: string;
  colorTo: string;
  size?: number;
}

export function CircularMeter({ value, label, colorFrom, colorTo, size = 160 }: CircularMeterProps) {
  const radius = size / 2 - 12;
  const circumference = 2 * Math.PI * radius;
  const animatedValue = useCountUp(value, 1600);
  const offset = circumference - (animatedValue / 100) * circumference;
  const gradientId = `meter-gradient-${label.replace(/\s+/g, "-")}`;

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <defs>
            <linearGradient id={gradientId} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor={colorFrom} />
              <stop offset="100%" stopColor={colorTo} />
            </linearGradient>
          </defs>
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="rgba(255,255,255,0.06)"
            strokeWidth={10}
          />
          <motion.circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={`url(#${gradientId})`}
            strokeWidth={10}
            strokeLinecap="round"
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset: offset }}
            transition={{ duration: 1.6, ease: "easeOut" }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-mono font-semibold text-2xl">{animatedValue.toFixed(0)}%</span>
        </div>
      </div>
      <p className="text-xs font-mono uppercase tracking-wider text-white/50">{label}</p>
    </div>
  );
}

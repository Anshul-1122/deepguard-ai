import { motion } from "framer-motion";
import { ShieldCheck, ShieldAlert } from "lucide-react";
import { cn } from "@/utils/cn";
import type { Verdict } from "@/types";

interface VerdictBadgeProps {
  verdict: Verdict;
  size?: "sm" | "md" | "lg";
  animated?: boolean;
}

const SIZE_STYLES = {
  sm: "text-xs px-3 py-1 gap-1.5",
  md: "text-sm px-4 py-1.5 gap-2",
  lg: "text-2xl px-8 py-4 gap-3",
};

const ICON_SIZE = { sm: 12, md: 16, lg: 28 };

export function VerdictBadge({ verdict, size = "md", animated = false }: VerdictBadgeProps) {
  const isReal = verdict === "REAL";
  const Icon = isReal ? ShieldCheck : ShieldAlert;

  const content = (
    <span
      className={cn(
        "inline-flex items-center font-display font-semibold rounded-full border",
        SIZE_STYLES[size],
        isReal
          ? "text-verdict-real bg-verdict-real/10 border-verdict-real/30"
          : "text-verdict-fake bg-verdict-fake/10 border-verdict-fake/30"
      )}
    >
      <Icon size={ICON_SIZE[size]} />
      {verdict}
    </span>
  );

  if (!animated) return content;

  return (
    <motion.div
      initial={{ scale: 0.7, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ type: "spring", stiffness: 260, damping: 18 }}
    >
      {content}
    </motion.div>
  );
}

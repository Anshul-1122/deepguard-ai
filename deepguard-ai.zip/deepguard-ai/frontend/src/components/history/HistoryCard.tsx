import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Trash2, Users } from "lucide-react";
import { VerdictBadge } from "@/components/ui/VerdictBadge";
import { formatDate } from "@/utils/format";
import type { ScanHistoryItem } from "@/types";

interface HistoryCardProps {
  item: ScanHistoryItem;
  onDelete: (id: string) => void;
  index: number;
}

export function HistoryCard({ item, onDelete, index }: HistoryCardProps) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.35, delay: Math.min(index * 0.04, 0.4) }}
      className="card group relative overflow-hidden"
    >
      <Link to={`/result/${item.id}`} className="block">
        <div className="relative rounded-xl overflow-hidden aspect-video mb-4 bg-white/5">
          {item.thumbnail_url ? (
            <img
              src={item.thumbnail_url}
              alt={item.original_filename}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-white/20 text-xs">
              No preview
            </div>
          )}
          <div className="absolute top-2 left-2">
            <VerdictBadge verdict={item.prediction} size="sm" />
          </div>
        </div>

        <p className="text-sm font-medium truncate mb-1">{item.original_filename}</p>
        <div className="flex items-center justify-between text-xs text-white/45">
          <span>{formatDate(item.created_at)}</span>
          <span className="flex items-center gap-1">
            <Users size={11} />
            {item.faces_detected}
          </span>
        </div>
        <div className="mt-3 pt-3 border-t border-white/[0.06] flex items-center justify-between">
          <span className="text-xs text-white/40">Confidence</span>
          <span className="font-mono text-sm">{item.confidence_score.toFixed(1)}%</span>
        </div>
      </Link>

      <button
        onClick={(e) => {
          e.preventDefault();
          onDelete(item.id);
        }}
        aria-label="Delete scan"
        className="absolute top-2 right-2 w-8 h-8 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center text-white/60 hover:text-verdict-fake hover:bg-black/70 transition-colors opacity-0 group-hover:opacity-100"
      >
        <Trash2 size={14} />
      </button>
    </motion.div>
  );
}

import { Search } from "lucide-react";

interface HistoryFiltersProps {
  search: string;
  onSearchChange: (value: string) => void;
  predictionFilter: "" | "REAL" | "FAKE";
  onPredictionFilterChange: (value: "" | "REAL" | "FAKE") => void;
}

const FILTERS: { label: string; value: "" | "REAL" | "FAKE" }[] = [
  { label: "All", value: "" },
  { label: "Real", value: "REAL" },
  { label: "Fake", value: "FAKE" },
];

export function HistoryFilters({
  search,
  onSearchChange,
  predictionFilter,
  onPredictionFilterChange,
}: HistoryFiltersProps) {
  return (
    <div className="flex flex-col sm:flex-row gap-3 mb-8">
      <div className="relative flex-1">
        <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" />
        <input
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Search by filename..."
          className="w-full glass rounded-full pl-11 pr-4 py-2.5 text-sm placeholder:text-white/30 outline-none focus:border-primary/40 border border-transparent transition-colors"
        />
      </div>

      <div className="flex items-center gap-1 glass rounded-full p-1 w-fit">
        {FILTERS.map((filter) => (
          <button
            key={filter.value}
            onClick={() => onPredictionFilterChange(filter.value)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
              predictionFilter === filter.value ? "bg-white/10 text-white" : "text-white/50 hover:text-white/80"
            }`}
          >
            {filter.label}
          </button>
        ))}
      </div>
    </div>
  );
}

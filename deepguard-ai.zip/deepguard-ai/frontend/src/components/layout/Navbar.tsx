import { useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Sun, Moon, ScanFace, LogOut } from "lucide-react";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/context/AuthContext";
import { cn } from "@/utils/cn";

const NAV_LINKS = [
  { label: "Home", to: "/" },
  { label: "Dashboard", to: "/dashboard" },
  { label: "History", to: "/history" },
];

export function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();
  const { isAuthenticated, user, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <header className="fixed top-0 inset-x-0 z-50 px-4 pt-4">
      <div className="mx-auto max-w-6xl glass rounded-2xl px-4 sm:px-6 py-3 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2.5 group" onClick={() => setMobileOpen(false)}>
          <motion.div
            whileHover={{ rotate: 8, scale: 1.05 }}
            className="relative w-9 h-9 rounded-xl bg-gradient-brand flex items-center justify-center shrink-0"
          >
            <ScanFace size={19} className="text-white" strokeWidth={2.2} />
            <span className="absolute inset-0 rounded-xl border border-white/20 animate-pulse-glow" />
          </motion.div>
          <span className="font-display font-semibold text-lg tracking-tight">
            DeepGuard <span className="text-secondary">AI</span>
          </span>
        </Link>

        <nav className="hidden md:flex items-center gap-1">
          {NAV_LINKS.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.to === "/"}
              className={({ isActive }) =>
                cn(
                  "px-4 py-2 rounded-full text-sm font-medium transition-colors",
                  isActive ? "text-white bg-white/10" : "text-white/60 hover:text-white hover:bg-white/5"
                )
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-3">
          <button
            onClick={toggleTheme}
            aria-label="Toggle theme"
            className="w-9 h-9 rounded-full flex items-center justify-center text-white/60 hover:text-white hover:bg-white/5 transition-colors"
          >
            {theme === "dark" ? <Sun size={17} /> : <Moon size={17} />}
          </button>

          {isAuthenticated ? (
            <div className="flex items-center gap-3 pl-3 border-l border-white/10">
              <span className="text-sm text-white/70">{user?.full_name || user?.email}</span>
              <button
                onClick={() => {
                  logout();
                  navigate("/");
                }}
                aria-label="Log out"
                className="w-9 h-9 rounded-full flex items-center justify-center text-white/60 hover:text-verdict-fake hover:bg-white/5 transition-colors"
              >
                <LogOut size={16} />
              </button>
            </div>
          ) : (
            <Link to="/login" className="btn-primary !py-2 !px-5 text-sm">
              Sign in
            </Link>
          )}
        </div>

        <button
          className="md:hidden text-white/80"
          onClick={() => setMobileOpen((prev) => !prev)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden mx-auto max-w-6xl glass rounded-2xl mt-2 overflow-hidden"
          >
            <div className="p-4 flex flex-col gap-1">
              {NAV_LINKS.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  end={link.to === "/"}
                  onClick={() => setMobileOpen(false)}
                  className={({ isActive }) =>
                    cn(
                      "px-4 py-3 rounded-xl text-sm font-medium transition-colors",
                      isActive ? "text-white bg-white/10" : "text-white/60"
                    )
                  }
                >
                  {link.label}
                </NavLink>
              ))}
              <div className="flex items-center justify-between px-4 py-3">
                <button onClick={toggleTheme} className="text-white/60 flex items-center gap-2 text-sm">
                  {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
                  Theme
                </button>
                {isAuthenticated ? (
                  <button onClick={logout} className="text-verdict-fake text-sm">
                    Log out
                  </button>
                ) : (
                  <Link to="/login" className="btn-primary !py-2 !px-4 text-sm">
                    Sign in
                  </Link>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

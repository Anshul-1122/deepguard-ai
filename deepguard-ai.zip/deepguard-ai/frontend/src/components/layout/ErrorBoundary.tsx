import { Component, type ErrorInfo, type ReactNode } from "react";
import { AlertTriangle } from "lucide-react";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
}

export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // In production, forward this to an error-tracking service (Sentry, etc).
    console.error("DeepGuard AI render error:", error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center px-6">
          <div className="card max-w-md text-center">
            <div className="w-14 h-14 rounded-2xl bg-verdict-fake/10 flex items-center justify-center mx-auto mb-4">
              <AlertTriangle size={26} className="text-verdict-fake" />
            </div>
            <h2 className="font-display text-xl font-semibold mb-2">Something went wrong</h2>
            <p className="text-sm text-white/60 mb-6">
              This page hit an unexpected error. Reloading usually fixes it.
            </p>
            <button onClick={() => window.location.reload()} className="btn-primary w-full">
              Reload page
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

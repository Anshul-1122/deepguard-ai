import { Link } from "react-router-dom";
import { ScanFace, Github, Twitter } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-white/[0.06] mt-32">
      <div className="max-w-6xl mx-auto px-6 py-12 grid grid-cols-1 md:grid-cols-4 gap-10">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2.5 mb-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-brand flex items-center justify-center">
              <ScanFace size={16} className="text-white" />
            </div>
            <span className="font-display font-semibold">
              DeepGuard <span className="text-secondary">AI</span>
            </span>
          </div>
          <p className="text-sm text-white/50 max-w-sm leading-relaxed">
            Explainable deepfake detection for images and video, powered by EfficientNetB0 and
            Grad-CAM visual reasoning. Built for newsrooms, trust & safety teams, and anyone who
            needs a second opinion on a face.
          </p>
        </div>

        <div>
          <p className="text-xs font-mono uppercase tracking-wider text-white/40 mb-4">Product</p>
          <ul className="space-y-2.5 text-sm text-white/60">
            <li><Link to="/dashboard" className="hover:text-white transition-colors">Dashboard</Link></li>
            <li><Link to="/history" className="hover:text-white transition-colors">Scan history</Link></li>
            <li><Link to="/#how-it-works" className="hover:text-white transition-colors">How it works</Link></li>
            <li><Link to="/#faq" className="hover:text-white transition-colors">FAQ</Link></li>
          </ul>
        </div>

        <div>
          <p className="text-xs font-mono uppercase tracking-wider text-white/40 mb-4">Connect</p>
          <div className="flex gap-3">
            <a
              href="https://github.com"
              target="_blank"
              rel="noreferrer"
              aria-label="GitHub"
              className="w-9 h-9 rounded-full glass flex items-center justify-center text-white/60 hover:text-white transition-colors"
            >
              <Github size={16} />
            </a>
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noreferrer"
              aria-label="Twitter"
              className="w-9 h-9 rounded-full glass flex items-center justify-center text-white/60 hover:text-white transition-colors"
            >
              <Twitter size={16} />
            </a>
          </div>
        </div>
      </div>

      <div className="border-t border-white/[0.06] py-6 px-6">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-2 text-xs text-white/40">
          <p>© {new Date().getFullYear()} DeepGuard AI. All rights reserved.</p>
          <p>Automated analysis — not a substitute for professional forensic review.</p>
        </div>
      </div>
    </footer>
  );
}

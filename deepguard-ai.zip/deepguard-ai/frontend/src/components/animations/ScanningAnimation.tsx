import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Scan, Brain, Fingerprint, Layers, Gauge, FlaskConical, CheckCircle2 } from "lucide-react";

const STAGES = [
  { label: "Detecting face", icon: Scan },
  { label: "Analyzing pixels", icon: Layers },
  { label: "Comparing features", icon: Fingerprint },
  { label: "AI thinking", icon: Brain },
  { label: "Generating heatmap", icon: FlaskConical },
  { label: "Calculating confidence", icon: Gauge },
  { label: "Prediction complete", icon: CheckCircle2 },
] as const;

interface ScanningAnimationProps {
  imageUrl?: string;
  /** If provided, external progress (0-100) drives the stage instead of the internal timer. */
  externalProgress?: number;
}

export function ScanningAnimation({ imageUrl, externalProgress }: ScanningAnimationProps) {
  const [internalStage, setInternalStage] = useState(0);

  useEffect(() => {
    if (externalProgress !== undefined) return;
    const interval = setInterval(() => {
      setInternalStage((prev) => Math.min(prev + 1, STAGES.length - 1));
    }, 900);
    return () => clearInterval(interval);
  }, [externalProgress]);

  const stageIndex =
    externalProgress !== undefined
      ? Math.min(Math.floor((externalProgress / 100) * STAGES.length), STAGES.length - 1)
      : internalStage;

  const CurrentIcon = STAGES[stageIndex].icon;

  return (
    <div className="flex flex-col items-center gap-8">
      <div className="relative w-64 h-64 rounded-2xl overflow-hidden glass-strong">
        {imageUrl && (
          <img src={imageUrl} alt="Analyzing upload" className="w-full h-full object-cover opacity-70" />
        )}

        {/* Neural-net node overlay */}
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 256 256">
          {[...Array(10)].map((_, i) => {
            const x = 30 + (i % 4) * 65;
            const y = 40 + Math.floor(i / 4) * 70;
            return (
              <motion.circle
                key={i}
                cx={x}
                cy={y}
                r={3}
                fill="#00E5FF"
                animate={{ opacity: [0.2, 1, 0.2] }}
                transition={{ duration: 1.6, repeat: Infinity, delay: i * 0.15 }}
              />
            );
          })}
        </svg>

        {/* Scanning laser sweep — the product's signature motif */}
        <motion.div
          className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-secondary to-transparent shadow-glow-cyan"
          animate={{ top: ["0%", "100%"] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        />

        <div className="absolute inset-0 border-2 border-secondary/20 rounded-2xl" />
      </div>

      <div className="flex flex-col items-center gap-3 min-h-[3rem]">
        <AnimatePresence mode="wait">
          <motion.div
            key={stageIndex}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.3 }}
            className="flex items-center gap-2.5 text-white/80"
          >
            <CurrentIcon size={18} className="text-secondary" />
            <span className="font-mono text-sm">{STAGES[stageIndex].label}...</span>
          </motion.div>
        </AnimatePresence>

        <div className="flex gap-1.5">
          {STAGES.map((_, i) => (
            <div
              key={i}
              className={`h-1 w-6 rounded-full transition-colors duration-300 ${
                i <= stageIndex ? "bg-gradient-brand" : "bg-white/10"
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ScanFace } from "lucide-react";

export function NotFoundPage() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 text-center">
      <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}>
        <div className="w-16 h-16 rounded-2xl bg-gradient-brand/20 flex items-center justify-center mx-auto mb-6">
          <ScanFace size={28} className="text-secondary" />
        </div>
        <h1 className="font-display text-6xl font-semibold mb-3 text-gradient">404</h1>
        <p className="text-white/50 mb-8">This page couldn't be detected — maybe it's a deepfake.</p>
        <Link to="/" className="btn-primary">
          Back to home
        </Link>
      </motion.div>
    </div>
  );
}

import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { UploadDropzone } from "@/components/dashboard/UploadDropzone";
import { RecentUploadsList } from "@/components/dashboard/RecentUploadsList";
import { StatusCard } from "@/components/dashboard/StatusCard";
import { ScanningAnimation } from "@/components/animations/ScanningAnimation";
import { predictImage, fetchHistory } from "@/services/scanService";
import { normalizeApiError } from "@/services/api";
import { useToast } from "@/context/ToastContext";
import type { ScanHistoryItem } from "@/types";

export function DashboardPage() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | undefined>();
  const [recentScans, setRecentScans] = useState<ScanHistoryItem[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(true);
  const [lastModelVersion, setLastModelVersion] = useState<string>();
  const [lastIsMock, setLastIsMock] = useState<boolean>();
  const navigate = useNavigate();
  const { showToast } = useToast();

  useEffect(() => {
    loadRecent();
  }, []);

  async function loadRecent() {
    try {
      setIsLoadingHistory(true);
      const res = await fetchHistory({ limit: 6 });
      setRecentScans(res.items);
    } catch (error) {
      // Silently degrade — the dashboard still works without recent history.
      console.error(error);
    } finally {
      setIsLoadingHistory(false);
    }
  }

  async function handleFileAccepted(file: File) {
    setPreviewUrl(URL.createObjectURL(file));
    setIsAnalyzing(true);
    try {
      const result = await predictImage(file);
      setLastModelVersion(result.model_version);
      setLastIsMock(result.is_mock_model);
      showToast(`Analysis complete: ${result.prediction}`, result.prediction === "FAKE" ? "error" : "success");
      navigate(`/result/${result.scan_id}`, { state: { result } });
    } catch (error) {
      const { message } = normalizeApiError(error);
      showToast(message, "error");
      setIsAnalyzing(false);
    }
  }

  return (
    <div className="max-w-6xl mx-auto px-6 pt-32 pb-20">
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="mb-10">
        <p className="label-eyebrow mb-2">Dashboard</p>
        <h1 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight">
          Analyze a photo
        </h1>
        <p className="text-white/50 mt-2">Upload a face image to check whether it's authentic or AI-generated.</p>
      </motion.div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="card min-h-[420px] flex items-center justify-center">
            {isAnalyzing ? (
              <ScanningAnimation imageUrl={previewUrl} />
            ) : (
              <div className="w-full">
                <UploadDropzone onFileAccepted={handleFileAccepted} />
              </div>
            )}
          </div>
        </div>

        <div className="flex flex-col gap-6">
          <StatusCard modelVersion={lastModelVersion} isMock={lastIsMock} />

          <div className="card">
            <h3 className="font-display font-semibold text-sm mb-4">Recent uploads</h3>
            <RecentUploadsList items={recentScans} isLoading={isLoadingHistory} />
          </div>
        </div>
      </div>
    </div>
  );
}

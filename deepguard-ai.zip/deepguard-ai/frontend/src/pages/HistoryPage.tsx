import { useCallback, useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { History as HistoryIcon } from "lucide-react";
import { HistoryFilters } from "@/components/history/HistoryFilters";
import { HistoryCard } from "@/components/history/HistoryCard";
import { Skeleton } from "@/components/ui/Skeleton";
import { fetchHistory, deleteScan } from "@/services/scanService";
import { normalizeApiError } from "@/services/api";
import { useToast } from "@/context/ToastContext";
import type { ScanHistoryItem } from "@/types";

export function HistoryPage() {
  const [items, setItems] = useState<ScanHistoryItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [predictionFilter, setPredictionFilter] = useState<"" | "REAL" | "FAKE">("");
  const { showToast } = useToast();

  const load = useCallback(async () => {
    try {
      setIsLoading(true);
      const res = await fetchHistory({ search, prediction: predictionFilter });
      setItems(res.items);
    } catch (error) {
      const { message } = normalizeApiError(error);
      showToast(message, "error");
    } finally {
      setIsLoading(false);
    }
  }, [search, predictionFilter, showToast]);

  useEffect(() => {
    const timeout = setTimeout(load, 300); // debounce search typing
    return () => clearTimeout(timeout);
  }, [load]);

  async function handleDelete(id: string) {
    const previous = items;
    setItems((prev) => prev.filter((item) => item.id !== id)); // optimistic
    try {
      await deleteScan(id);
      showToast("Scan deleted", "success");
    } catch (error) {
      setItems(previous); // revert on failure
      const { message } = normalizeApiError(error);
      showToast(message, "error");
    }
  }

  return (
    <div className="max-w-6xl mx-auto px-6 pt-32 pb-20">
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <p className="label-eyebrow mb-2">History</p>
        <h1 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight">Scan history</h1>
        <p className="text-white/50 mt-2">Every analysis you've run, searchable and filterable.</p>
      </motion.div>

      <HistoryFilters
        search={search}
        onSearchChange={setSearch}
        predictionFilter={predictionFilter}
        onPredictionFilterChange={setPredictionFilter}
      />

      {isLoading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {[...Array(6)].map((_, i) => (
            <Skeleton key={i} className="h-64 rounded-2xl" />
          ))}
        </div>
      ) : items.length === 0 ? (
        <div className="text-center py-24">
          <HistoryIcon size={32} className="text-white/20 mx-auto mb-4" />
          <p className="text-white/40">No scans match your filters yet.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          <AnimatePresence>
            {items.map((item, i) => (
              <HistoryCard key={item.id} item={item} onDelete={handleDelete} index={i} />
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}

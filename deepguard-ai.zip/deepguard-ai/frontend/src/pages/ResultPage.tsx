import { useEffect, useState } from "react";
import { useLocation, useParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Download, ArrowLeft, AlertTriangle, Sparkles } from "lucide-react";
import { VerdictBadge } from "@/components/ui/VerdictBadge";
import { CircularMeter } from "@/components/ui/CircularMeter";
import { ImageComparison } from "@/components/result/ImageComparison";
import { ProbabilityChart } from "@/components/result/ProbabilityChart";
import { MetadataPanel } from "@/components/result/MetadataPanel";
import { Skeleton } from "@/components/ui/Skeleton";
import { reportDownloadUrl, fetchHistory } from "@/services/scanService";
import { useToast } from "@/context/ToastContext";
import type { PredictionResult } from "@/types";

export function ResultPage() {
  const { scanId } = useParams<{ scanId: string }>();
  const location = useLocation();
  const { showToast } = useToast();
  const [result, setResult] = useState<PredictionResult | undefined>(
    (location.state as { result?: PredictionResult } | undefined)?.result
  );
  const [isLoading, setIsLoading] = useState(!result);

  useEffect(() => {
    // If we arrived here directly (e.g. via a shared link or the History
    // page) rather than right after an upload, we won't have the result in
    // route state — recover it from the history list instead.
    if (result || !scanId) return;

    (async () => {
      try {
        setIsLoading(true);
        const history = await fetchHistory({ limit: 200 });
        const match = history.items.find((item) => item.id === scanId);
        if (match) {
          setResult({
            scan_id: match.id,
            prediction: match.prediction,
            confidence_score: match.confidence_score,
            authenticity_score: match.authenticity_score,
            real_probability: match.prediction === "REAL" ? match.confidence_score / 100 : 1 - match.confidence_score / 100,
            fake_probability: match.prediction === "FAKE" ? match.confidence_score / 100 : 1 - match.confidence_score / 100,
            faces_detected: match.faces_detected,
            explanation: "",
            heatmap_url: match.heatmap_url,
            original_url: match.original_url,
            inference_time_ms: 0,
            model_version: "",
            is_mock_model: false,
            created_at: match.created_at,
          });
        } else {
          showToast("Couldn't find that scan.", "error");
        }
      } catch {
        showToast("Couldn't load this result.", "error");
      } finally {
        setIsLoading(false);
      }
    })();
  }, [scanId, result, showToast]);

  if (isLoading) {
    return (
      <div className="max-w-5xl mx-auto px-6 pt-32 pb-20">
        <Skeleton className="h-10 w-48 mb-8" />
        <div className="grid lg:grid-cols-2 gap-8">
          <Skeleton className="aspect-square rounded-2xl" />
          <div className="flex flex-col gap-4">
            <Skeleton className="h-24 rounded-2xl" />
            <Skeleton className="h-40 rounded-2xl" />
            <Skeleton className="h-40 rounded-2xl" />
          </div>
        </div>
      </div>
    );
  }

  if (!result) {
    return (
      <div className="max-w-lg mx-auto px-6 pt-40 pb-20 text-center">
        <AlertTriangle size={32} className="text-white/30 mx-auto mb-4" />
        <h2 className="font-display text-xl font-semibold mb-2">Result not found</h2>
        <p className="text-white/50 mb-6">This scan may have been deleted, or the link is invalid.</p>
        <Link to="/dashboard" className="btn-primary">
          Run a new scan
        </Link>
      </div>
    );
  }

  const isFake = result.prediction === "FAKE";

  return (
    <div className="max-w-5xl mx-auto px-6 pt-32 pb-20">
      <Link to="/dashboard" className="inline-flex items-center gap-2 text-sm text-white/50 hover:text-white transition-colors mb-8">
        <ArrowLeft size={15} />
        Back to dashboard
      </Link>

      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-wrap items-center justify-between gap-4 mb-10"
      >
        <div className="flex items-center gap-4">
          <VerdictBadge verdict={result.prediction} size="lg" animated />
          {result.is_mock_model && (
            <span className="inline-flex items-center gap-1.5 text-xs font-mono text-white/40 glass rounded-full px-3 py-1.5">
              <Sparkles size={11} />
              Demo prediction
            </span>
          )}
        </div>
        <a
          href={reportDownloadUrl(result.scan_id)}
          download
          className="btn-secondary text-sm"
        >
          <Download size={15} />
          Download report
        </a>
      </motion.div>

      <div className="grid lg:grid-cols-2 gap-8">
        <motion.div initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}>
          <ImageComparison originalUrl={result.original_url} heatmapUrl={result.heatmap_url} />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 12 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.15 }}
          className="flex flex-col gap-6"
        >
          <div className="card flex items-center justify-around">
            <CircularMeter
              value={result.confidence_score}
              label="Confidence"
              colorFrom={isFake ? "#EF4444" : "#22C55E"}
              colorTo={isFake ? "#F97316" : "#00E5FF"}
              size={140}
            />
            <CircularMeter
              value={result.authenticity_score}
              label="Authenticity"
              colorFrom="#7C3AED"
              colorTo="#00E5FF"
              size={140}
            />
          </div>

          <div className="card">
            <h3 className="font-display font-semibold text-sm mb-3">Probability breakdown</h3>
            <ProbabilityChart realProbability={result.real_probability} fakeProbability={result.fake_probability} />
          </div>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="grid lg:grid-cols-2 gap-6 mt-6"
      >
        {result.explanation && (
          <div className="card">
            <h3 className="font-display font-semibold text-sm mb-3">AI explanation</h3>
            <p className="text-sm text-white/60 leading-relaxed">{result.explanation}</p>
          </div>
        )}
        <MetadataPanel result={result} />
      </motion.div>
    </div>
  );
}

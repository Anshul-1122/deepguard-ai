import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { motion } from "framer-motion";
import { UserPlus, Mail, Lock, User, ScanFace } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { normalizeApiError } from "@/services/api";

interface SignupFormValues {
  fullName: string;
  email: string;
  password: string;
}

export function SignupPage() {
  const { signup } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<SignupFormValues>();

  async function onSubmit(values: SignupFormValues) {
    setIsSubmitting(true);
    try {
      await signup(values.email, values.password, values.fullName);
      showToast("Account created — welcome to DeepGuard AI!", "success");
      navigate("/dashboard");
    } catch (error) {
      const { message } = normalizeApiError(error);
      showToast(message, "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-6 pt-20">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-sm card glow-border"
      >
        <div className="flex flex-col items-center mb-8">
          <div className="w-12 h-12 rounded-2xl bg-gradient-brand flex items-center justify-center mb-4">
            <ScanFace size={22} className="text-white" />
          </div>
          <h1 className="font-display text-2xl font-semibold">Create your account</h1>
          <p className="text-sm text-white/50 mt-1">Save and revisit your scan history</p>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-4">
          <div>
            <label className="text-xs text-white/50 mb-1.5 block">Full name</label>
            <div className="relative">
              <User size={15} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" />
              <input
                {...register("fullName")}
                className="w-full glass rounded-xl pl-11 pr-4 py-2.5 text-sm outline-none focus:border-primary/40 border border-transparent transition-colors"
                placeholder="Ada Lovelace"
              />
            </div>
          </div>

          <div>
            <label className="text-xs text-white/50 mb-1.5 block">Email</label>
            <div className="relative">
              <Mail size={15} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" />
              <input
                type="email"
                {...register("email", { required: "Email is required" })}
                className="w-full glass rounded-xl pl-11 pr-4 py-2.5 text-sm outline-none focus:border-primary/40 border border-transparent transition-colors"
                placeholder="you@example.com"
              />
            </div>
            {errors.email && <p className="text-xs text-verdict-fake mt-1.5">{errors.email.message}</p>}
          </div>

          <div>
            <label className="text-xs text-white/50 mb-1.5 block">Password</label>
            <div className="relative">
              <Lock size={15} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" />
              <input
                type="password"
                {...register("password", {
                  required: "Password is required",
                  minLength: { value: 8, message: "At least 8 characters" },
                })}
                className="w-full glass rounded-xl pl-11 pr-4 py-2.5 text-sm outline-none focus:border-primary/40 border border-transparent transition-colors"
                placeholder="At least 8 characters"
              />
            </div>
            {errors.password && <p className="text-xs text-verdict-fake mt-1.5">{errors.password.message}</p>}
          </div>

          <button type="submit" disabled={isSubmitting} className="btn-primary mt-2 disabled:opacity-60">
            <UserPlus size={16} />
            {isSubmitting ? "Creating account..." : "Create account"}
          </button>
        </form>

        <p className="text-center text-sm text-white/50 mt-6">
          Already have an account?{" "}
          <Link to="/login" className="text-secondary hover:underline">
            Sign in
          </Link>
        </p>
      </motion.div>
    </div>
  );
}

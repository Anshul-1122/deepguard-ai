"""
Core product router: upload + predict, list/search history, delete a scan,
and download its PDF report. This is the endpoint set the frontend's
Dashboard, Result, and History pages talk to.
"""
from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, status
from fastapi.responses import FileResponse
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.config import settings
from app.database import get_db
from app.models.scan import Scan
from app.models.user import User
from app.schemas.scan import (
    DeleteResponse,
    PredictionResult,
    ScanHistoryItem,
    ScanHistoryResponse,
)
from app.services.report_service import generate_scan_report
from app.services.scan_service import run_prediction_pipeline
from app.utils.deps import get_optional_user

router = APIRouter(tags=["Scans"])


def _static_url(relative_path: str | None) -> str | None:
    if not relative_path:
        return None
    return f"/static/{relative_path}"


def _scan_to_prediction_result(scan: Scan) -> PredictionResult:
    return PredictionResult(
        scan_id=scan.id,
        prediction=scan.prediction,
        confidence_score=scan.confidence_score,
        authenticity_score=scan.authenticity_score,
        real_probability=scan.real_probability,
        fake_probability=scan.fake_probability,
        faces_detected=scan.faces_detected,
        explanation=scan.explanation,
        heatmap_url=_static_url(scan.heatmap_path),
        original_url=_static_url(scan.stored_path),
        inference_time_ms=scan.inference_time_ms,
        model_version=scan.model_version,
        is_mock_model=getattr(scan, "_is_mock_model", False),
        created_at=scan.created_at,
    )


@router.post("/predict", response_model=PredictionResult, status_code=status.HTTP_201_CREATED)
async def predict(
    file: UploadFile,
    db: Session = Depends(get_db),
    current_user: User | None = Depends(get_optional_user),
):
    """
    Run the full detection pipeline on an uploaded image:
    face detection -> preprocessing -> EfficientNet inference -> Grad-CAM ->
    persisted history row. Works for both guests and logged-in users.
    """
    try:
        scan = await run_prediction_pipeline(db, file, owner_id=current_user.id if current_user else None)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    return _scan_to_prediction_result(scan)


@router.get("/history", response_model=ScanHistoryResponse)
def get_history(
    db: Session = Depends(get_db),
    current_user: User | None = Depends(get_optional_user),
    search: str | None = Query(default=None, description="Filter by original filename"),
    prediction: str | None = Query(default=None, description="Filter by REAL or FAKE"),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
):
    query = db.query(Scan)
    if current_user:
        query = query.filter(Scan.owner_id == current_user.id)

    if search:
        query = query.filter(Scan.original_filename.ilike(f"%{search}%"))
    if prediction:
        query = query.filter(Scan.prediction == prediction.upper())

    total = query.count()
    scans = query.order_by(Scan.created_at.desc()).offset(offset).limit(limit).all()

    items = [
        ScanHistoryItem(
            id=s.id,
            media_type=s.media_type,
            original_filename=s.original_filename,
            original_url=_static_url(s.stored_path),
            heatmap_url=_static_url(s.heatmap_path),
            thumbnail_url=_static_url(s.thumbnail_path),
            prediction=s.prediction,
            confidence_score=s.confidence_score,
            authenticity_score=s.authenticity_score,
            faces_detected=s.faces_detected,
            created_at=s.created_at,
        )
        for s in scans
    ]
    return ScanHistoryResponse(total=total, items=items)


@router.delete("/history/{scan_id}", response_model=DeleteResponse)
def delete_scan(
    scan_id: str,
    db: Session = Depends(get_db),
    current_user: User | None = Depends(get_optional_user),
):
    query = db.query(Scan).filter(Scan.id == scan_id)
    if current_user:
        query = query.filter(Scan.owner_id == current_user.id)
    scan = query.first()

    if not scan:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Scan not found")

    db.delete(scan)
    db.commit()
    return DeleteResponse(success=True, message="Scan deleted")


@router.get("/report/{scan_id}")
def download_report(
    scan_id: str,
    db: Session = Depends(get_db),
    current_user: User | None = Depends(get_optional_user),
):
    query = db.query(Scan).filter(Scan.id == scan_id)
    if current_user:
        query = query.filter(Scan.owner_id == current_user.id)
    scan = query.first()

    if not scan:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Scan not found")

    report_path = generate_scan_report(scan)
    return FileResponse(
        path=report_path,
        media_type="application/pdf",
        filename=f"DeepGuard_Report_{scan.prediction}_{scan.id[:8]}.pdf",
    )

"""
Face detection using OpenCV's built-in Haar Cascade classifier.

We use Haar Cascades (bundled with opencv-python, no extra download needed)
rather than a DNN detector so the service works offline out of the box.
For production accuracy, swap `_CASCADE_PATH` for a DNN-based detector
(e.g. RetinaFace or MediaPipe) — the public interface (`detect_faces`)
stays the same either way.
"""
from dataclasses import dataclass

import cv2
import numpy as np

from app.config import settings

_CASCADE_PATH = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
_face_cascade = cv2.CascadeClassifier(_CASCADE_PATH)


@dataclass
class FaceBox:
    x: int
    y: int
    w: int
    h: int

    def as_expanded_crop(self, image_shape: tuple[int, int], margin: float) -> tuple[int, int, int, int]:
        """Return (x1, y1, x2, y2) expanded by `margin` fraction, clamped to image bounds."""
        img_h, img_w = image_shape
        mx, my = int(self.w * margin), int(self.h * margin)
        x1 = max(0, self.x - mx)
        y1 = max(0, self.y - my)
        x2 = min(img_w, self.x + self.w + mx)
        y2 = min(img_h, self.y + self.h + my)
        return x1, y1, x2, y2


def detect_faces(bgr_image: np.ndarray) -> list[FaceBox]:
    """Detect all faces in a BGR image (OpenCV convention). Returns boxes sorted largest-first."""
    gray = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2GRAY)
    gray = cv2.equalizeHist(gray)

    detections = _face_cascade.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=6,
        minSize=(60, 60),
    )

    boxes = [FaceBox(x=int(x), y=int(y), w=int(w), h=int(h)) for (x, y, w, h) in detections]
    boxes.sort(key=lambda b: b.w * b.h, reverse=True)
    return boxes


def crop_primary_face(bgr_image: np.ndarray) -> tuple[np.ndarray, int]:
    """
    Return (cropped_face_bgr, faces_detected_count).
    If no face is found, falls back to a center-crop of the full image so the
    pipeline still produces a prediction rather than hard-failing — the
    frontend surfaces `faces_detected == 0` so the user knows no face was found.
    """
    boxes = detect_faces(bgr_image)
    h, w = bgr_image.shape[:2]

    if not boxes:
        side = min(h, w)
        cy, cx = h // 2, w // 2
        crop = bgr_image[
            max(0, cy - side // 2): cy + side // 2,
            max(0, cx - side // 2): cx + side // 2,
        ]
        return crop, 0

    primary = boxes[0]
    x1, y1, x2, y2 = primary.as_expanded_crop((h, w), settings.FACE_MARGIN)
    return bgr_image[y1:y2, x1:x2], len(boxes)

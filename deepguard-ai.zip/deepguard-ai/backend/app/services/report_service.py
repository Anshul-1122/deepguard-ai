"""
Generates a downloadable PDF analysis report for a single scan, including
the original image, the Grad-CAM heatmap, and the full prediction breakdown.
"""
import datetime as dt
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    Image,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from app.config import settings
from app.models.scan import Scan

_BRAND_PURPLE = colors.HexColor("#7C3AED")
_BRAND_CYAN = colors.HexColor("#00E5FF")
_INK = colors.HexColor("#18181B")
_MUTED = colors.HexColor("#71717A")


def generate_scan_report(scan: Scan) -> Path:
    """Build the PDF for `scan` and return its filesystem path under settings.REPORT_DIR."""
    output_path = settings.REPORT_DIR / f"{scan.id}_report.pdf"

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "DeepGuardTitle", parent=styles["Title"], textColor=_BRAND_PURPLE, fontSize=24, spaceAfter=4
    )
    subtitle_style = ParagraphStyle("DeepGuardSubtitle", parent=styles["Normal"], textColor=_MUTED, fontSize=10)
    section_style = ParagraphStyle(
        "SectionHeading", parent=styles["Heading2"], textColor=_INK, spaceBefore=16, spaceAfter=8
    )
    body_style = ParagraphStyle("Body", parent=styles["Normal"], textColor=_INK, fontSize=10, leading=15)

    verdict_color = colors.HexColor("#EF4444") if scan.prediction == "FAKE" else colors.HexColor("#22C55E")
    verdict_style = ParagraphStyle(
        "Verdict", parent=styles["Heading1"], textColor=verdict_color, fontSize=28, spaceAfter=2
    )

    doc = SimpleDocTemplate(
        str(output_path), pagesize=letter, topMargin=0.6 * inch, bottomMargin=0.6 * inch
    )
    story = []

    story.append(Paragraph("DeepGuard AI", title_style))
    story.append(Paragraph("Deepfake Detection Report", subtitle_style))
    story.append(Spacer(1, 18))

    story.append(Paragraph(scan.prediction, verdict_style))
    story.append(
        Paragraph(
            f"Confidence: {scan.confidence_score:.1f}%  &nbsp;&nbsp;|&nbsp;&nbsp; "
            f"Authenticity score: {scan.authenticity_score:.1f}%",
            body_style,
        )
    )
    story.append(Spacer(1, 12))

    # Side-by-side original + heatmap images, when available on disk.
    image_row = []
    original_abs = settings.STATIC_DIR / scan.stored_path
    if original_abs.exists():
        image_row.append(Image(str(original_abs), width=2.4 * inch, height=2.4 * inch))
    if scan.heatmap_path:
        heatmap_abs = settings.STATIC_DIR / scan.heatmap_path
        if heatmap_abs.exists():
            image_row.append(Image(str(heatmap_abs), width=2.4 * inch, height=2.4 * inch))

    if image_row:
        img_table = Table([image_row], colWidths=[2.6 * inch] * len(image_row))
        img_table.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "CENTER")]))
        story.append(img_table)
        caption_cells = [Paragraph("Original", subtitle_style)]
        if len(image_row) > 1:
            caption_cells.append(Paragraph("Grad-CAM heatmap (suspicious regions)", subtitle_style))
        caption_table = Table([caption_cells], colWidths=[2.6 * inch] * len(caption_cells))
        caption_table.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "CENTER")]))
        story.append(caption_table)

    story.append(Paragraph("Analysis Details", section_style))
    details_data = [
        ["Filename", scan.original_filename],
        ["Media type", scan.media_type.capitalize()],
        ["Faces detected", str(scan.faces_detected)],
        ["Fake probability", f"{scan.fake_probability * 100:.2f}%"],
        ["Real probability", f"{scan.real_probability * 100:.2f}%"],
        ["Inference time", f"{scan.inference_time_ms:.1f} ms"],
        ["Model version", scan.model_version or "n/a"],
        ["Scan date", scan.created_at.strftime("%B %d, %Y at %H:%M UTC")],
    ]
    details_table = Table(details_data, colWidths=[2 * inch, 4 * inch])
    details_table.setStyle(
        TableStyle(
            [
                ("FONTSIZE", (0, 0), (-1, -1), 9.5),
                ("TEXTCOLOR", (0, 0), (0, -1), _MUTED),
                ("TEXTCOLOR", (1, 0), (1, -1), _INK),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("LINEBELOW", (0, 0), (-1, -2), 0.5, colors.HexColor("#E4E4E7")),
            ]
        )
    )
    story.append(details_table)

    story.append(Paragraph("Explanation", section_style))
    story.append(Paragraph(scan.explanation or "No explanation available.", body_style))

    story.append(Paragraph("Recommendation", section_style))
    if scan.prediction == "FAKE":
        recommendation = (
            "This media shows strong indicators of AI generation or manipulation. "
            "Treat it as unverified before sharing, publishing, or acting on it. "
            "Consider corroborating with the original source or additional forensic tools."
        )
    else:
        recommendation = (
            "This media shows no strong indicators of manipulation. As with any automated "
            "system, this is a probabilistic assessment, not a legal or forensic guarantee."
        )
    story.append(Paragraph(recommendation, body_style))

    story.append(Spacer(1, 24))
    story.append(
        Paragraph(
            f"Generated by DeepGuard AI on {dt.datetime.utcnow().strftime('%B %d, %Y at %H:%M UTC')}. "
            "Automated analysis — not a substitute for professional forensic review.",
            subtitle_style,
        )
    )

    doc.build(story)
    return output_path

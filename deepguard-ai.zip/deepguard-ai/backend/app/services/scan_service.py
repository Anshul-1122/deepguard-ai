"""
Scan service: orchestrates the end-to-end workflow described in the product
brief — upload -> face detection -> preprocessing -> model -> prediction ->
heatmap -> store history — and is the single call site used by the router.
"""
import cv2
import numpy as np
from fastapi import UploadFile
from sqlalchemy.orm import Session

from app.config import settings
from app.models.scan import Scan
from app.services.model_service import ModelService
from app.utils.image import save_upload, validate_upload


async def run_prediction_pipeline(
    db: Session,
    file: UploadFile,
    owner_id: str | None,
) -> Scan:
    """
    Full pipeline for a single image upload. Video support extends this by
    sampling frames upstream and averaging fake_probability across frames;
    the per-frame path is identical to what's implemented here.
    """
    media_type = validate_upload(file)

    stored_path = await save_upload(file, settings.UPLOAD_DIR)

    image_bgr = cv2.imread(str(stored_path))
    if image_bgr is None:
        # Could happen for corrupt uploads or (currently unsupported) video bytes
        # arriving at the image pipeline; caller-facing error is raised upstream.
        raise ValueError("Could not decode uploaded file as an image.")

    model_service = ModelService.get_instance()
    result = model_service.predict(image_bgr)

    heatmap_path = None
    if result.heatmap_bgr is not None:
        heatmap_path = settings.HEATMAP_DIR / f"{stored_path.stem}_heatmap.jpg"
        cv2.imwrite(str(heatmap_path), result.heatmap_bgr)

    scan = Scan(
        owner_id=owner_id,
        media_type=media_type,
        original_filename=file.filename or "upload",
        stored_path=str(stored_path.relative_to(settings.STATIC_DIR)),
        heatmap_path=str(heatmap_path.relative_to(settings.STATIC_DIR)) if heatmap_path else None,
        thumbnail_path=str(stored_path.relative_to(settings.STATIC_DIR)),
        prediction=result.prediction,
        confidence_score=result.confidence_score,
        authenticity_score=result.authenticity_score,
        fake_probability=result.fake_probability,
        real_probability=result.real_probability,
        faces_detected=result.faces_detected,
        explanation=result.explanation,
        inference_time_ms=result.inference_time_ms,
        model_version=result.model_version,
    )
    db.add(scan)
    db.commit()
    db.refresh(scan)

    # Stash the mock flag for the router to include in the response
    # (not persisted on the model since it's a runtime property of the service, not the scan).
    scan._is_mock_model = result.is_mock_model  # type: ignore[attr-defined]
    return scan

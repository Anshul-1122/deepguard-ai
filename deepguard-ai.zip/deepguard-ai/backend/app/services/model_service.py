"""
Model service: the single place that owns the trained EfficientNetB0 model,
runs preprocessing + inference, and produces a Grad-CAM overlay.

Design note — mock fallback:
This project ships with a real training script (see `training/scripts/train.py`)
that produces `training/saved_models/deepguard_efficientnet.h5`. Training
requires a GPU and the Kaggle deepfake dataset, neither of which are
available in this authoring environment. So that the full application is
runnable end-to-end without those, this service auto-detects whether trained
weights exist on disk:
  - If `settings.MODEL_PATH` exists -> loads and uses the real model.
  - If not -> uses `_MockDeepfakeModel`, a deterministic stand-in that
    produces plausible, stable outputs (seeded by image content, not random
    noise) so the UI/UX and API contract are fully exercised.
Every API response includes `is_mock_model` so callers always know which
mode produced a given result — this is never hidden from the client.
"""
import hashlib
import time
from dataclasses import dataclass

import cv2
import numpy as np
import tensorflow as tf

from app.config import settings
from app.gradcam.gradcam import (
    make_gradcam_heatmap,
    overlay_heatmap_on_image,
    suspicious_region_summary,
)
from app.services.face_detector import crop_primary_face


@dataclass
class InferenceOutput:
    prediction: str                 # "REAL" | "FAKE"
    fake_probability: float         # 0-1
    real_probability: float         # 0-1
    confidence_score: float         # 0-100
    authenticity_score: float       # 0-100
    faces_detected: int
    explanation: str
    heatmap_bgr: np.ndarray | None  # None only if heatmap generation genuinely fails
    inference_time_ms: float
    model_version: str
    is_mock_model: bool


class _MockDeepfakeModel:
    """
    Deterministic placeholder used only when no trained weights are present.
    Derives a stable pseudo-probability from the image's own pixel content
    (via a hash of downsampled pixels) so the same image always yields the
    same result, and different images plausibly differ — never a random
    coin flip that would make the demo feel fake to a reviewer.
    """

    version = "mock-v0 (no trained weights found)"

    def predict(self, face_bgr: np.ndarray) -> float:
        small = cv2.resize(face_bgr, (16, 16))
        digest = hashlib.sha256(small.tobytes()).hexdigest()
        # Map first 8 hex chars to a float in [0, 1]
        fake_prob = int(digest[:8], 16) / 0xFFFFFFFF
        return float(fake_prob)

    def gradcam_heatmap(self, face_bgr: np.ndarray) -> np.ndarray:
        """Fabricate a plausible-looking activation map centered near the eyes/mouth region."""
        h, w = 7, 7  # mimic EfficientNetB0's last conv spatial size for 224 input
        yy, xx = np.mgrid[0:h, 0:w]
        cy, cx = h * 0.4, w * 0.5  # slightly upper-center, like eye region
        heatmap = np.exp(-(((yy - cy) ** 2) / (2 * 2.0**2) + ((xx - cx) ** 2) / (2 * 2.5**2)))
        return (heatmap / heatmap.max()).astype(np.float32)


class ModelService:
    _instance: "ModelService | None" = None

    def __init__(self):
        self.is_mock = not settings.MODEL_PATH.exists()
        if self.is_mock:
            self.model = _MockDeepfakeModel()
            self.model_version = self.model.version
            self.last_conv_layer = None
        else:
            self.model = tf.keras.models.load_model(settings.MODEL_PATH)
            self.model_version = f"efficientnet-b0-{settings.MODEL_PATH.stem}"
            self.last_conv_layer = None  # resolved lazily on first Grad-CAM call

    @classmethod
    def get_instance(cls) -> "ModelService":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def _preprocess(self, face_bgr: np.ndarray) -> np.ndarray:
        """Resize to model input size, convert BGR->RGB, apply EfficientNet preprocessing."""
        resized = cv2.resize(face_bgr, (settings.IMAGE_SIZE, settings.IMAGE_SIZE))
        rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
        batch = np.expand_dims(rgb.astype(np.float32), axis=0)
        return tf.keras.applications.efficientnet.preprocess_input(batch)

    def _build_explanation(self, prediction: str, confidence: float, region_info: dict, faces_detected: int) -> str:
        if faces_detected == 0:
            return (
                "No face was clearly detected, so this result is based on the full image. "
                "For best accuracy, upload a clear, front-facing photo."
            )

        confidence_word = "high" if confidence >= 85 else ("moderate" if confidence >= 60 else "low")
        if prediction == "FAKE":
            region_txt = (
                f" primarily around the {', '.join(region_info['regions'])} region(s)"
                if region_info["regions"]
                else ""
            )
            return (
                f"The model detected patterns consistent with AI-generated or manipulated media"
                f"{region_txt}, with {confidence_word} confidence ({confidence:.1f}%). "
                "Common deepfake artifacts include unnatural skin texture, inconsistent lighting, "
                "and blending irregularities around facial boundaries."
            )
        return (
            f"The model found no strong indicators of manipulation, with {confidence_word} confidence "
            f"({confidence:.1f}%). Facial texture, lighting consistency, and edge boundaries "
            "were consistent with an authentic, unaltered photo."
        )

    def predict(self, image_bgr: np.ndarray) -> InferenceOutput:
        start = time.perf_counter()

        face_bgr, faces_detected = crop_primary_face(image_bgr)
        preprocessed = self._preprocess(face_bgr)

        if self.is_mock:
            fake_probability = self.model.predict(face_bgr)
            raw_heatmap = self.model.gradcam_heatmap(face_bgr)
        else:
            fake_probability = float(self.model.predict(preprocessed, verbose=0)[0][0])
            if self.last_conv_layer is None:
                from app.gradcam.gradcam import find_last_conv_layer_name

                self.last_conv_layer = find_last_conv_layer_name(self.model)
            raw_heatmap = make_gradcam_heatmap(preprocessed, self.model, self.last_conv_layer)

        real_probability = 1.0 - fake_probability
        prediction = "FAKE" if fake_probability >= 0.5 else "REAL"
        confidence_score = round(max(fake_probability, real_probability) * 100, 2)
        # Authenticity score: intuitive "how real does this look" metric for the UI gauge.
        authenticity_score = round(real_probability * 100, 2)

        region_info = suspicious_region_summary(raw_heatmap)
        heatmap_overlay = overlay_heatmap_on_image(raw_heatmap, face_bgr)

        explanation = self._build_explanation(prediction, confidence_score, region_info, faces_detected)
        elapsed_ms = round((time.perf_counter() - start) * 1000, 1)

        return InferenceOutput(
            prediction=prediction,
            fake_probability=round(fake_probability, 4),
            real_probability=round(real_probability, 4),
            confidence_score=confidence_score,
            authenticity_score=authenticity_score,
            faces_detected=faces_detected,
            explanation=explanation,
            heatmap_bgr=heatmap_overlay,
            inference_time_ms=elapsed_ms,
            model_version=self.model_version,
            is_mock_model=self.is_mock,
        )

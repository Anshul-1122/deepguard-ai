"""
Database engine and session management.

Uses SQLite by default (development) and switches transparently to
PostgreSQL in production by changing only the DATABASE_URL env var —
no other code in the app needs to change.
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

from app.config import settings

# SQLite requires this connect_arg when used from multiple threads (FastAPI's
# threadpool for sync endpoints). Postgres does not need it, so we only add
# it conditionally.
connect_args = {"check_same_thread": False} if settings.DATABASE_URL.startswith("sqlite") else {}

engine = create_engine(settings.DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    """FastAPI dependency that yields a DB session and guarantees it's closed."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

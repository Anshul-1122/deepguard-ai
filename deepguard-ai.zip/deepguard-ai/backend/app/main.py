"""
DeepGuard AI — FastAPI application entrypoint.

Run locally with:
    uvicorn app.main:app --reload --port 8000
"""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.database import Base, engine
from app.routers import auth, scans


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Create tables if they don't exist. For production, prefer Alembic
    # migrations over create_all — this is convenient for local/dev setup.
    Base.metadata.create_all(bind=engine)

    # Warm the model service at startup so the first request isn't slow,
    # and so we log clearly whether real weights or the mock model loaded.
    from app.services.model_service import ModelService

    service = ModelService.get_instance()
    mode = "MOCK (no trained weights found)" if service.is_mock else "TRAINED MODEL"
    print(f"[DeepGuard AI] Model service ready — mode: {mode} — version: {service.model_version}")

    yield
    # (no teardown needed)


app = FastAPI(
    title=settings.APP_NAME,
    description="Deepfake detection platform powered by EfficientNetB0 and Grad-CAM explainability.",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory=settings.STATIC_DIR), name="static")

app.include_router(auth.router, prefix=settings.API_V1_PREFIX)
app.include_router(scans.router, prefix=settings.API_V1_PREFIX)


@app.get("/", tags=["Health"])
def root():
    return {"service": settings.APP_NAME, "status": "online"}


@app.get("/health", tags=["Health"])
def health_check():
    from app.services.model_service import ModelService

    service = ModelService.get_instance()
    return {
        "status": "ok",
        "model_mode": "mock" if service.is_mock else "trained",
        "model_version": service.model_version,
    }

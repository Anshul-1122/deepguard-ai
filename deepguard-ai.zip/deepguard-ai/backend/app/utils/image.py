"""Small shared helpers for validating uploads and generating unique file paths."""
import uuid
from pathlib import Path

from fastapi import HTTPException, UploadFile, status

from app.config import settings


def validate_upload(file: UploadFile) -> str:
    """
    Validate content-type against the allow-list and return "image" or "video".
    Raises HTTPException(415) for unsupported types.
    """
    if file.content_type in settings.ALLOWED_IMAGE_TYPES:
        return "image"
    if file.content_type in settings.ALLOWED_VIDEO_TYPES:
        return "video"
    raise HTTPException(
        status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
        detail=f"Unsupported file type: {file.content_type}. "
        f"Allowed: {settings.ALLOWED_IMAGE_TYPES + settings.ALLOWED_VIDEO_TYPES}",
    )


def new_stored_path(original_filename: str, directory: Path) -> Path:
    """Build a collision-free path for a new upload, preserving its extension."""
    ext = Path(original_filename).suffix.lower() or ".bin"
    unique_name = f"{uuid.uuid4().hex}{ext}"
    return directory / unique_name


async def save_upload(file: UploadFile, directory: Path) -> Path:
    """Stream an UploadFile to disk under `directory`, enforcing the size limit."""
    destination = new_stored_path(file.filename or "upload", directory)
    max_bytes = settings.MAX_UPLOAD_MB * 1024 * 1024

    size = 0
    with open(destination, "wb") as out_file:
        while chunk := await file.read(1024 * 1024):
            size += len(chunk)
            if size > max_bytes:
                out_file.close()
                destination.unlink(missing_ok=True)
                raise HTTPException(
                    status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                    detail=f"File exceeds the {settings.MAX_UPLOAD_MB}MB limit",
                )
            out_file.write(chunk)

    return destination

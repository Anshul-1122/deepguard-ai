"""Scan table — one row per uploaded media prediction (the 'history' data)."""
import datetime as dt
import uuid

from sqlalchemy import Column, DateTime, Float, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from app.database import Base


class Scan(Base):
    __tablename__ = "scans"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    owner_id = Column(String, ForeignKey("users.id"), nullable=True)  # nullable: allow anonymous use

    media_type = Column(String, nullable=False)          # "image" | "video"
    original_filename = Column(String, nullable=False)
    stored_path = Column(String, nullable=False)          # relative path under /static/uploads
    heatmap_path = Column(String, nullable=True)          # relative path under /static/heatmaps
    thumbnail_path = Column(String, nullable=True)

    prediction = Column(String, nullable=False)           # "REAL" | "FAKE"
    confidence_score = Column(Float, nullable=False)      # 0-100, model's confidence in the prediction
    authenticity_score = Column(Float, nullable=False)    # 0-100, higher = more likely authentic
    fake_probability = Column(Float, nullable=False)      # raw model probability of "fake" class
    real_probability = Column(Float, nullable=False)

    faces_detected = Column(Integer, default=0)
    explanation = Column(String, nullable=True)           # human-readable rationale
    inference_time_ms = Column(Float, nullable=True)
    model_version = Column(String, nullable=True)

    created_at = Column(DateTime, default=dt.datetime.utcnow, index=True)

    owner = relationship("User", back_populates="scans")

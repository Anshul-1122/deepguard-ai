"""
Grad-CAM (Gradient-weighted Class Activation Mapping).

Given a trained CNN and an input image, produces a heatmap over the last
convolutional layer showing which spatial regions most influenced the
model's prediction for a given class. Used here to highlight the regions
of a face that most drove the REAL/FAKE decision.

Reference: Selvaraju et al., "Grad-CAM: Visual Explanations from Deep
Networks via Gradient-based Localization" (2017).
"""
import cv2
import numpy as np
import tensorflow as tf


def find_last_conv_layer_name(model: tf.keras.Model) -> str:
    """Walk the model backwards and return the name of the last Conv2D-family layer."""
    for layer in reversed(model.layers):
        if len(layer.output_shape) == 4:  # (batch, H, W, channels) — spatial feature map
            return layer.name
    raise ValueError("No 4D (convolutional) layer found in model — cannot compute Grad-CAM.")


def make_gradcam_heatmap(
    preprocessed_batch: np.ndarray,
    model: tf.keras.Model,
    last_conv_layer_name: str | None = None,
    class_index: int = 0,
) -> np.ndarray:
    """
    Compute a Grad-CAM heatmap for a single preprocessed image batch (shape 1,H,W,3).

    Returns a 2D numpy array in [0, 1], the same spatial size as the last
    conv layer's output (typically much smaller than the input — caller
    resizes it back up for overlay).
    """
    if last_conv_layer_name is None:
        last_conv_layer_name = find_last_conv_layer_name(model)

    grad_model = tf.keras.models.Model(
        inputs=model.inputs,
        outputs=[model.get_layer(last_conv_layer_name).output, model.output],
    )

    with tf.GradientTape() as tape:
        conv_outputs, predictions = grad_model(preprocessed_batch)
        # Binary sigmoid output: a single unit. class_index kept for API
        # symmetry with multi-class models.
        class_channel = predictions[:, class_index] if predictions.shape[-1] > 1 else predictions[:, 0]

    grads = tape.gradient(class_channel, conv_outputs)
    # Average gradient over width/height -> importance weight per channel
    pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))

    conv_outputs = conv_outputs[0]
    heatmap = conv_outputs @ pooled_grads[..., tf.newaxis]
    heatmap = tf.squeeze(heatmap)

    # ReLU: we only care about features that positively influence the class
    heatmap = tf.maximum(heatmap, 0) / (tf.math.reduce_max(heatmap) + 1e-8)
    return heatmap.numpy()


def overlay_heatmap_on_image(
    heatmap: np.ndarray,
    original_bgr: np.ndarray,
    alpha: float = 0.45,
    colormap: int = cv2.COLORMAP_JET,
) -> np.ndarray:
    """Resize `heatmap` to match `original_bgr` and alpha-blend it as a color overlay."""
    h, w = original_bgr.shape[:2]
    heatmap_resized = cv2.resize(heatmap, (w, h))
    heatmap_uint8 = np.uint8(255 * heatmap_resized)
    colored_heatmap = cv2.applyColorMap(heatmap_uint8, colormap)

    overlaid = cv2.addWeighted(colored_heatmap, alpha, original_bgr, 1 - alpha, 0)
    return overlaid


def suspicious_region_summary(heatmap: np.ndarray, threshold: float = 0.6) -> dict:
    """
    Summarize which coarse region(s) of the face carry the strongest activation,
    used to generate the plain-English explanation text.
    """
    h, w = heatmap.shape
    ys, xs = np.where(heatmap >= threshold)

    if len(xs) == 0:
        return {"regions": [], "coverage_pct": 0.0}

    regions = set()
    for x, y in zip(xs, ys):
        horizontal = "left" if x < w / 3 else ("right" if x > 2 * w / 3 else "center")
        vertical = "upper" if y < h / 3 else ("lower" if y > 2 * h / 3 else "mid")
        regions.add(f"{vertical}-{horizontal}")

    coverage_pct = round(100 * len(xs) / (h * w), 1)
    return {"regions": sorted(regions), "coverage_pct": coverage_pct}

"""
Central configuration for the DeepGuard AI backend.

All environment-dependent values (paths, secrets, CORS, model location)
are declared here as a single typed source of truth. Every other module
imports `settings` from this file instead of reading os.environ directly.
"""
from functools import lru_cache
from pathlib import Path
from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent  # backend/


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # --- App ---
    APP_NAME: str = "DeepGuard AI"
    ENVIRONMENT: str = "development"  # development | production
    DEBUG: bool = True

    # --- API / CORS ---
    API_V1_PREFIX: str = "/api"
    CORS_ORIGINS: List[str] = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ]

    # --- Auth ---
    JWT_SECRET_KEY: str = "CHANGE_ME_IN_PRODUCTION_env_var_JWT_SECRET_KEY"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # 24 hours

    # --- Database ---
    # SQLite for local dev; swap DATABASE_URL for a postgres:// URL in production.
    DATABASE_URL: str = f"sqlite:///{BASE_DIR / 'deepguard.db'}"

    # --- Storage paths ---
    STATIC_DIR: Path = BASE_DIR / "app" / "static"
    UPLOAD_DIR: Path = BASE_DIR / "app" / "static" / "uploads"
    HEATMAP_DIR: Path = BASE_DIR / "app" / "static" / "heatmaps"
    REPORT_DIR: Path = BASE_DIR / "app" / "static" / "reports"

    # --- Model ---
    MODEL_PATH: Path = BASE_DIR / "training" / "saved_models" / "deepguard_efficientnet.h5"
    IMAGE_SIZE: int = 224  # EfficientNetB0 default input resolution
    FACE_MARGIN: float = 0.35  # extra crop margin around detected face, as fraction of box size

    # --- Upload limits ---
    MAX_UPLOAD_MB: int = 15
    ALLOWED_IMAGE_TYPES: List[str] = ["image/jpeg", "image/png", "image/webp"]
    ALLOWED_VIDEO_TYPES: List[str] = ["video/mp4", "video/quicktime", "video/webm"]


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()

# Ensure runtime directories exist at import time.
for _dir in (settings.UPLOAD_DIR, settings.HEATMAP_DIR, settings.REPORT_DIR):
    _dir.mkdir(parents=True, exist_ok=True)

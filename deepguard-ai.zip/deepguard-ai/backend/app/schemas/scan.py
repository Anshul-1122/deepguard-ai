"""Request/response schemas for the prediction and history endpoints."""
import datetime as dt
from typing import Literal

from pydantic import BaseModel


class PredictionResult(BaseModel):
    """What the /predict endpoint returns immediately after inference."""

    scan_id: str
    prediction: Literal["REAL", "FAKE"]
    confidence_score: float          # 0-100
    authenticity_score: float        # 0-100
    real_probability: float          # 0-1
    fake_probability: float          # 0-1
    faces_detected: int
    explanation: str
    heatmap_url: str | None
    original_url: str
    inference_time_ms: float
    model_version: str
    is_mock_model: bool               # true if no trained weights were found
    created_at: dt.datetime

    class Config:
        from_attributes = True


class ScanHistoryItem(BaseModel):
    id: str
    media_type: str
    original_filename: str
    original_url: str
    heatmap_url: str | None
    thumbnail_url: str | None
    prediction: str
    confidence_score: float
    authenticity_score: float
    faces_detected: int
    created_at: dt.datetime

    class Config:
        from_attributes = True


class ScanHistoryResponse(BaseModel):
    total: int
    items: list[ScanHistoryItem]


class DeleteResponse(BaseModel):
    success: bool
    message: str

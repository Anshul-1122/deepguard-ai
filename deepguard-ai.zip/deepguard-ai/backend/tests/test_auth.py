def test_signup_creates_user_and_returns_token(client):
    response = client.post(
        "/api/auth/signup",
        json={"email": "ada@example.com", "password": "supersecret123", "full_name": "Ada Lovelace"},
    )
    assert response.status_code == 201
    body = response.json()
    assert body["user"]["email"] == "ada@example.com"
    assert body["access_token"]


def test_signup_rejects_duplicate_email(client):
    payload = {"email": "dupe@example.com", "password": "supersecret123"}
    first = client.post("/api/auth/signup", json=payload)
    assert first.status_code == 201

    second = client.post("/api/auth/signup", json=payload)
    assert second.status_code == 409


def test_login_with_correct_credentials(client):
    client.post("/api/auth/signup", json={"email": "grace@example.com", "password": "hopper12345"})
    response = client.post("/api/auth/login", json={"email": "grace@example.com", "password": "hopper12345"})
    assert response.status_code == 200
    assert response.json()["access_token"]


def test_login_with_wrong_password_fails(client):
    client.post("/api/auth/signup", json={"email": "alan@example.com", "password": "correcthorse1"})
    response = client.post("/api/auth/login", json={"email": "alan@example.com", "password": "wrongpassword"})
    assert response.status_code == 401


def test_me_requires_authentication(client):
    response = client.get("/api/auth/me")
    assert response.status_code == 401


def test_me_returns_current_user_with_valid_token(client):
    signup = client.post("/api/auth/signup", json={"email": "margaret@example.com", "password": "hamilton123"})
    token = signup.json()["access_token"]

    response = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 200
    assert response.json()["email"] == "margaret@example.com"

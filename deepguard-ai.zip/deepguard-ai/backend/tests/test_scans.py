import io

import numpy as np


def _fake_jpeg_bytes() -> bytes:
    """Generate a tiny in-memory JPEG so tests don't depend on a fixture file on disk."""
    import cv2

    image = np.full((256, 256, 3), 200, dtype=np.uint8)
    success, encoded = cv2.imencode(".jpg", image)
    assert success
    return encoded.tobytes()


def test_predict_rejects_unsupported_file_type(client):
    response = client.post(
        "/api/predict",
        files={"file": ("note.txt", io.BytesIO(b"not an image"), "text/plain")},
    )
    assert response.status_code == 415


def test_predict_returns_prediction_for_valid_image(client):
    response = client.post(
        "/api/predict",
        files={"file": ("test.jpg", io.BytesIO(_fake_jpeg_bytes()), "image/jpeg")},
    )
    assert response.status_code == 201
    body = response.json()
    assert body["prediction"] in ("REAL", "FAKE")
    assert 0 <= body["confidence_score"] <= 100
    assert 0 <= body["authenticity_score"] <= 100
    assert "scan_id" in body


def test_history_lists_created_scans(client):
    client.post(
        "/api/predict",
        files={"file": ("history_test.jpg", io.BytesIO(_fake_jpeg_bytes()), "image/jpeg")},
    )
    response = client.get("/api/history")
    assert response.status_code == 200
    body = response.json()
    assert body["total"] >= 1
    assert any(item["original_filename"] == "history_test.jpg" for item in body["items"])


def test_delete_scan_removes_it_from_history(client):
    predict_res = client.post(
        "/api/predict",
        files={"file": ("to_delete.jpg", io.BytesIO(_fake_jpeg_bytes()), "image/jpeg")},
    )
    scan_id = predict_res.json()["scan_id"]

    delete_res = client.delete(f"/api/history/{scan_id}")
    assert delete_res.status_code == 200
    assert delete_res.json()["success"] is True

    delete_again = client.delete(f"/api/history/{scan_id}")
    assert delete_again.status_code == 404


def test_report_download_returns_pdf(client):
    predict_res = client.post(
        "/api/predict",
        files={"file": ("report_test.jpg", io.BytesIO(_fake_jpeg_bytes()), "image/jpeg")},
    )
    scan_id = predict_res.json()["scan_id"]

    report_res = client.get(f"/api/report/{scan_id}")
    assert report_res.status_code == 200
    assert report_res.headers["content-type"] == "application/pdf"

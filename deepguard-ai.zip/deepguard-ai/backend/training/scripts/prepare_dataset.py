"""
Downloads a public Kaggle deepfake dataset and arranges it into the
`training/dataset/{real,fake}/` layout expected by `train.py`.

Prerequisites:
    pip install kaggle
    Place your Kaggle API token at ~/.kaggle/kaggle.json
    (Get it from https://www.kaggle.com/settings -> API -> Create New Token)

Usage:
    python -m training.scripts.prepare_dataset --dataset xhlulu/140k-real-and-fake-faces

Any Kaggle deepfake face dataset works as long as it has clearly separated
real/fake images; adjust SOURCE_REAL_DIRS / SOURCE_FAKE_DIRS below to match
the specific dataset's folder names after download.
"""
import argparse
import shutil
import zipfile
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
TRAINING_DIR = SCRIPT_DIR.parent
RAW_DOWNLOAD_DIR = TRAINING_DIR / "dataset_raw"
DATASET_DIR = TRAINING_DIR / "dataset"


def download_from_kaggle(dataset_slug: str):
    """Downloads and unzips a Kaggle dataset via the official Kaggle CLI/API."""
    try:
        import kaggle  # noqa: F401  (import triggers credential check)
    except OSError as exc:
        raise SystemExit(
            "Kaggle credentials not found. Place your API token at ~/.kaggle/kaggle.json "
            "(see https://www.kaggle.com/settings -> API -> Create New Token)."
        ) from exc

    RAW_DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    print(f"Downloading '{dataset_slug}' from Kaggle ...")
    kaggle.api.dataset_download_files(dataset_slug, path=str(RAW_DOWNLOAD_DIR), unzip=False)

    zips = list(RAW_DOWNLOAD_DIR.glob("*.zip"))
    for zip_path in zips:
        print(f"Extracting {zip_path.name} ...")
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(RAW_DOWNLOAD_DIR)


def organize_into_class_folders(real_source_dirs: list[Path], fake_source_dirs: list[Path]):
    """Copy images from arbitrary source folder names into dataset/{real,fake}/."""
    real_out = DATASET_DIR / "real"
    fake_out = DATASET_DIR / "fake"
    real_out.mkdir(parents=True, exist_ok=True)
    fake_out.mkdir(parents=True, exist_ok=True)

    valid_ext = {".jpg", ".jpeg", ".png"}

    def _copy_all(sources: list[Path], dest: Path, label: str):
        count = 0
        for src_dir in sources:
            if not src_dir.exists():
                print(f"  (skip) {src_dir} not found")
                continue
            for img_path in src_dir.rglob("*"):
                if img_path.suffix.lower() in valid_ext:
                    shutil.copy2(img_path, dest / f"{label}_{count:06d}{img_path.suffix.lower()}")
                    count += 1
        print(f"  {label}: {count} images copied -> {dest}")

    print("Organizing dataset into class folders ...")
    _copy_all(real_source_dirs, real_out, "real")
    _copy_all(fake_source_dirs, fake_out, "fake")


def main():
    parser = argparse.ArgumentParser(description="Prepare a Kaggle deepfake dataset for training.")
    parser.add_argument("--dataset", type=str, required=True, help="Kaggle dataset slug, e.g. xhlulu/140k-real-and-fake-faces")
    parser.add_argument(
        "--real-dirs",
        nargs="*",
        default=["real_and_fake_face_detection/real_and_fake_face/training_real"],
        help="Sub-paths (relative to the extracted dataset) containing REAL images.",
    )
    parser.add_argument(
        "--fake-dirs",
        nargs="*",
        default=["real_and_fake_face_detection/real_and_fake_face/training_fake"],
        help="Sub-paths (relative to the extracted dataset) containing FAKE images.",
    )
    args = parser.parse_args()

    download_from_kaggle(args.dataset)

    real_dirs = [RAW_DOWNLOAD_DIR / p for p in args.real_dirs]
    fake_dirs = [RAW_DOWNLOAD_DIR / p for p in args.fake_dirs]
    organize_into_class_folders(real_dirs, fake_dirs)

    print(f"\nDone. Dataset ready at: {DATASET_DIR}")
    print("Next: python -m training.scripts.train --epochs 20")


if __name__ == "__main__":
    main()

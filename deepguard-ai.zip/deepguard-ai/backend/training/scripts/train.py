"""
Train an EfficientNetB0-based binary classifier (REAL vs FAKE) via transfer
learning on a Kaggle deepfake face dataset.

Expected dataset layout (this matches common Kaggle deepfake datasets, e.g.
"140k Real and Fake Faces" or "Deepfake and real images"):

    training/dataset/
        real/
            img_0001.jpg
            img_0002.jpg
            ...
        fake/
            img_0001.jpg
            img_0002.jpg
            ...

Usage:
    cd backend
    python -m training.scripts.train --epochs 20 --batch-size 32

Outputs:
    training/saved_models/deepguard_efficientnet.h5   (best checkpoint)
    training/saved_models/training_history.json
    training/saved_models/evaluation_report.json      (precision/recall/F1/ROC-AUC)
    training/saved_models/confusion_matrix.png
    training/saved_models/roc_curve.png
"""
import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # headless-safe backend for servers/CI without a display
import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from tensorflow.keras import layers, models
from tensorflow.keras.applications import EfficientNetB0
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from tensorflow.keras.preprocessing.image import ImageDataGenerator

SCRIPT_DIR = Path(__file__).resolve().parent
TRAINING_DIR = SCRIPT_DIR.parent               # backend/training
DATASET_DIR = TRAINING_DIR / "dataset"
SAVED_MODELS_DIR = TRAINING_DIR / "saved_models"
SAVED_MODELS_DIR.mkdir(parents=True, exist_ok=True)

IMAGE_SIZE = 224
CLASS_NAMES = ["fake", "real"]  # alphabetical order matches Keras' inferred label order


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train DeepGuard AI's deepfake detector.")
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--fine-tune-epochs", type=int, default=10)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--fine-tune-lr", type=float, default=1e-5)
    parser.add_argument("--unfreeze-layers", type=int, default=30, help="Number of top layers to unfreeze for fine-tuning.")
    parser.add_argument("--dataset-dir", type=str, default=str(DATASET_DIR))
    return parser.parse_args()


def build_data_generators(dataset_dir: str, batch_size: int):
    """
    ImageDataGenerator with the augmentations specified in the product brief:
    flip, rotation, zoom, brightness, and contrast (via brightness_range +
    channel shifts, since Keras' ImageDataGenerator has no direct "contrast"
    knob — this is the standard way to approximate it).
    """
    train_datagen = ImageDataGenerator(
        preprocessing_function=tf.keras.applications.efficientnet.preprocess_input,
        rotation_range=20,
        zoom_range=0.15,
        horizontal_flip=True,
        brightness_range=(0.8, 1.2),
        channel_shift_range=20.0,
        validation_split=0.2,
    )
    # Validation/test data must NOT be augmented — only preprocessed.
    eval_datagen = ImageDataGenerator(
        preprocessing_function=tf.keras.applications.efficientnet.preprocess_input,
        validation_split=0.2,
    )

    train_gen = train_datagen.flow_from_directory(
        dataset_dir,
        target_size=(IMAGE_SIZE, IMAGE_SIZE),
        batch_size=batch_size,
        class_mode="binary",
        classes=CLASS_NAMES,
        subset="training",
        shuffle=True,
        seed=42,
    )
    val_gen = eval_datagen.flow_from_directory(
        dataset_dir,
        target_size=(IMAGE_SIZE, IMAGE_SIZE),
        batch_size=batch_size,
        class_mode="binary",
        classes=CLASS_NAMES,
        subset="validation",
        shuffle=False,
        seed=42,
    )
    return train_gen, val_gen


def build_model(learning_rate: float) -> tf.keras.Model:
    """EfficientNetB0 backbone (ImageNet weights, frozen) + a binary classification head."""
    base_model = EfficientNetB0(
        include_top=False,
        weights="imagenet",
        input_shape=(IMAGE_SIZE, IMAGE_SIZE, 3),
        pooling="avg",
    )
    base_model.trainable = False  # freeze initial layers for the first training phase

    inputs = layers.Input(shape=(IMAGE_SIZE, IMAGE_SIZE, 3))
    x = base_model(inputs, training=False)
    x = layers.Dropout(0.3)(x)
    x = layers.Dense(128, activation="relu")(x)
    x = layers.Dropout(0.2)(x)
    outputs = layers.Dense(1, activation="sigmoid", name="fake_probability")(x)

    model = models.Model(inputs, outputs, name="deepguard_efficientnet")
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=learning_rate),
        loss="binary_crossentropy",
        metrics=[
            "accuracy",
            tf.keras.metrics.Precision(name="precision"),
            tf.keras.metrics.Recall(name="recall"),
            tf.keras.metrics.AUC(name="auc"),
        ],
    )
    return model, base_model


def get_callbacks(checkpoint_path: Path) -> list:
    return [
        EarlyStopping(monitor="val_auc", mode="max", patience=5, restore_best_weights=True, verbose=1),
        ModelCheckpoint(
            filepath=str(checkpoint_path),
            monitor="val_auc",
            mode="max",
            save_best_only=True,
            verbose=1,
        ),
        ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=3, min_lr=1e-7, verbose=1),
    ]


def evaluate_model(model: tf.keras.Model, val_gen) -> dict:
    """Compute accuracy, precision, recall, F1, ROC-AUC, and save confusion matrix + ROC plots."""
    val_gen.reset()
    y_true = val_gen.classes
    y_prob = model.predict(val_gen, verbose=1).ravel()
    y_pred = (y_prob >= 0.5).astype(int)

    report = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred)),
        "recall": float(recall_score(y_true, y_pred)),
        "f1_score": float(f1_score(y_true, y_pred)),
        "roc_auc": float(roc_auc_score(y_true, y_prob)),
    }

    cm = confusion_matrix(y_true, y_pred)
    fig, ax = plt.subplots(figsize=(5, 5))
    ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=CLASS_NAMES).plot(ax=ax, cmap="Purples")
    ax.set_title("Confusion Matrix — DeepGuard AI")
    fig.tight_layout()
    fig.savefig(SAVED_MODELS_DIR / "confusion_matrix.png", dpi=150)
    plt.close(fig)

    fpr, tpr, _ = roc_curve(y_true, y_prob)
    fig, ax = plt.subplots(figsize=(5, 5))
    ax.plot(fpr, tpr, color="#7C3AED", linewidth=2, label=f"ROC curve (AUC = {report['roc_auc']:.3f})")
    ax.plot([0, 1], [0, 1], color="#71717A", linestyle="--", linewidth=1)
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title("ROC Curve — DeepGuard AI")
    ax.legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(SAVED_MODELS_DIR / "roc_curve.png", dpi=150)
    plt.close(fig)

    return report


def main():
    args = parse_args()
    checkpoint_path = SAVED_MODELS_DIR / "deepguard_efficientnet.h5"

    print(f"[1/5] Loading dataset from {args.dataset_dir} ...")
    train_gen, val_gen = build_data_generators(args.dataset_dir, args.batch_size)
    print(f"      Train samples: {train_gen.samples} | Validation samples: {val_gen.samples}")

    print("[2/5] Building EfficientNetB0 transfer-learning model ...")
    model, base_model = build_model(args.learning_rate)
    model.summary()

    print(f"[3/5] Phase 1 — training classification head ({args.epochs} epochs, backbone frozen) ...")
    history_1 = model.fit(
        train_gen,
        validation_data=val_gen,
        epochs=args.epochs,
        callbacks=get_callbacks(checkpoint_path),
    )

    print(f"[4/5] Phase 2 — fine-tuning top {args.unfreeze_layers} backbone layers ...")
    base_model.trainable = True
    for layer in base_model.layers[: -args.unfreeze_layers]:
        layer.trainable = False  # keep earlier layers frozen; only fine-tune the top

    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=args.fine_tune_lr),
        loss="binary_crossentropy",
        metrics=[
            "accuracy",
            tf.keras.metrics.Precision(name="precision"),
            tf.keras.metrics.Recall(name="recall"),
            tf.keras.metrics.AUC(name="auc"),
        ],
    )
    history_2 = model.fit(
        train_gen,
        validation_data=val_gen,
        epochs=args.fine_tune_epochs,
        callbacks=get_callbacks(checkpoint_path),
    )

    print("[5/5] Evaluating best checkpoint and saving reports ...")
    best_model = tf.keras.models.load_model(checkpoint_path)
    evaluation_report = evaluate_model(best_model, val_gen)
    print(json.dumps(evaluation_report, indent=2))

    combined_history = {
        "phase_1": {k: [float(v) for v in vals] for k, vals in history_1.history.items()},
        "phase_2": {k: [float(v) for v in vals] for k, vals in history_2.history.items()},
    }
    (SAVED_MODELS_DIR / "training_history.json").write_text(json.dumps(combined_history, indent=2))
    (SAVED_MODELS_DIR / "evaluation_report.json").write_text(json.dumps(evaluation_report, indent=2))

    print(f"\nDone. Best model saved to: {checkpoint_path}")
    print("Copy/symlink this file to backend/training/saved_models/deepguard_efficientnet.h5")
    print("(already the default path) and restart the API to load real predictions.")


if __name__ == "__main__":
    main()
